"""
output/telegram_bot.py — Telegram Bot Listener
================================================
All commands require a leading / (slash gate active for security):
  /scan  /help  /config    (Telegram autocomplete shows / commands)

Commands:
  /scan / scan TSLA / scan TSLA AAPL
  /stopscan
  /cancelscan     — cancel a scan currently running
  /lastscan       — summary table of last scan (top 10)
  /fullresult     — page 1 of full ranked results (10 per page)
  /fullresult 2   — page 2, etc.
  /next           — next page of results
  /previous       — previous page of results
  /result 5       — full detail card for opportunity #5
  /score          — explain how the 0-100 score is calculated
  /price SPY
  /movers
  /config         — show current scan config
  set <param> <value>  — change a config parameter live
  set reset       — clear ALL overrides and restore defaults
  /askclaude <question>  — ask Claude AI (Anthropic)
  /askllama <question>   — ask Llama AI (OpenRouter)
  /health         — full system health check (IBKR, Supabase, Claude API, OpenRouter)
  /stopbot        — gracefully stop the bot (password required: killbot)
  /help
"""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import os
import json
import logging
import signal
import threading
import time
import urllib.request
import urllib.parse
from datetime import datetime
from typing import Optional, List

log = logging.getLogger(__name__)

TELEGRAM_API      = "https://api.telegram.org/bot{token}/{method}"
ANTHROPIC_API     = "https://api.anthropic.com/v1/messages"
CLAUDE_MODEL      = "claude-sonnet-4-6"
OPENROUTER_API    = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_MODEL  = "meta-llama/llama-3.3-70b-instruct"

# ── Results paging ────────────────────────────────────────────────────────
RESULTS_PAGE_SIZE = 10
LASTSCAN_PREVIEW  = 10

# ── stopbot password ──────────────────────────────────────────────────────
STOPBOT_PASSWORD        = "killbot"   # password required to stop bot via Telegram
STOPBOT_TIMEOUT_SECS    = 60         # auto-cancel pending stopbot after this many seconds

PRESET_SYMBOLS = {
    "SPY":    ("SPY",     "S&P 500 ETF",       "stock"),
    "QQQ":    ("QQQ",     "Nasdaq 100 ETF",    "stock"),
    "DIA":    ("DIA",     "Dow Jones ETF",     "stock"),
    "VIX":    ("^VIX",    "VIX Fear Index",    "index"),
    "DJI":    ("^DJI",    "Dow Jones",         "index"),
    "SPX":    ("^GSPC",   "S&P 500 Index",     "index"),
    "NDX":    ("^NDX",    "Nasdaq 100 Index",  "index"),
    "BTC":    ("BTC-USD", "Bitcoin",           "crypto"),
    "ETH":    ("ETH-USD", "Ethereum",          "crypto"),
    "SOL":    ("SOL-USD", "Solana",            "crypto"),
    "BNB":    ("BNB-USD", "BNB",               "crypto"),
    "GOLD":   ("GC=F",    "Gold Futures",      "commodity"),
    "OIL":    ("CL=F",    "Crude Oil Futures", "commodity"),
    "SILVER": ("SI=F",    "Silver Futures",    "commodity"),
    "AAPL":   ("AAPL",    "Apple",             "stock"),
    "MSFT":   ("MSFT",    "Microsoft",         "stock"),
    "NVDA":   ("NVDA",    "NVIDIA",            "stock"),
    "TSLA":   ("TSLA",    "Tesla",             "stock"),
    "AMZN":   ("AMZN",    "Amazon",            "stock"),
    "META":   ("META",    "Meta",              "stock"),
    "GOOGL":  ("GOOGL",   "Alphabet",          "stock"),
    "AMD":    ("AMD",     "AMD",               "stock"),
}

MOVERS_STOCKS  = ["AAPL", "MSFT", "NVDA", "TSLA", "AMZN", "META", "GOOGL", "AMD",
                   "SPY", "QQQ", "NFLX", "BABA", "INTC", "PYPL", "CRM", "UBER"]
MOVERS_CRYPTO  = ["BTC-USD", "ETH-USD", "SOL-USD", "BNB-USD", "XRP-USD", "DOGE-USD"]
MOVERS_INDICES = ["^GSPC", "^NDX", "^DJI", "^VIX", "^RUT"]

DEFAULT_WATCHLIST = ["SPY", "QQQ", "AAPL", "MSFT", "NVDA", "TSLA", "AMZN", "META", "AMD"]

# ── Settable config parameters ────────────────────────────────────────────
SETTABLE_PARAMS = {
    "min_dte":        ("min_dte",               int,   "Min days to expiry"),
    "max_dte":        ("max_dte",               int,   "Max days to expiry"),
    "strike_pct":     ("strike_range_pct",      float, "Strike range +/-% (e.g. 0.10 = 10%)"),
    "min_premium":    ("min_premium",           float, "Min option premium $"),
    "min_theta":      ("min_theta",             float, "Min daily theta $"),
    "min_iv_rank":    ("min_iv_rank",           float, "Min IV rank 0-100 (0 = disabled)"),
    "min_iv":         ("min_iv",                float, "Min raw IV floor (e.g. 0.40 = 40%, 0 = disabled)"),
    "min_ann_return": ("min_annualised_return", float, "Min annualised return (e.g. 0.05 = 5%)"),
    "cc_delta_min":   ("cc_delta_min",          float, "CC min delta"),
    "cc_delta_max":   ("cc_delta_max",          float, "CC max delta"),
    "csp_delta_min":  ("csp_delta_min",         float, "CSP min delta"),
    "csp_delta_max":  ("csp_delta_max",         float, "CSP max delta"),
    "min_oi":         ("min_open_interest",     int,   "Min open interest (0 = disabled)"),
    "max_spread":     ("max_bid_ask_spread_pct",float, "Max bid/ask spread % (e.g. 0.30 = 30%)"),
    "strategy":       ("strategy",              str,   "Strategy: cc / csp / both"),
    "autostar":       ("autostar_threshold",    float, "Auto-star score threshold (0 = disabled, e.g. 80 = auto-star score >= 80)"),
}

# ── Claude AI system prompt ───────────────────────────────────────────────
CLAUDE_SYSTEM_PROMPT = """You are an expert options trader and financial advisor assistant
embedded in a Telegram trading bot. The user runs a Wheel Strategy scanner (Covered Calls
and Cash-Secured Puts) on US stocks using IBKR TWS and Python.

Answer any question the user asks — options trading, Greeks, strategy, market concepts,
finance, or anything else. Be concise and direct. Use plain text only — no markdown
headers, no bullet symbols, no asterisks. Keep responses under 800 characters so they
fit cleanly in a Telegram message. If the answer genuinely needs more detail, give the
most important 2-3 points and offer to elaborate."""


# ── Yahoo Finance helpers ─────────────────────────────────────────────────

def _yahoo_fetch(symbol: str) -> Optional[dict]:
    try:
        url = (f"https://query1.finance.yahoo.com/v8/finance/chart/"
               f"{urllib.parse.quote(symbol)}?interval=1d&range=2d")
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        meta       = data["chart"]["result"][0]["meta"]
        price      = meta.get("regularMarketPrice") or meta.get("previousClose", 0)
        prev_close = meta.get("chartPreviousClose") or meta.get("previousClose", price)
        change     = price - prev_close
        change_pct = (change / prev_close * 100) if prev_close else 0
        return {
            "symbol":       symbol,
            "price":        price,
            "prev_close":   prev_close,
            "change":       change,
            "change_pct":   change_pct,
            "name":         meta.get("longName") or meta.get("shortName", symbol),
            "market_state": meta.get("marketState", "CLOSED"),
        }
    except Exception as e:
        log.debug("Yahoo fetch failed for %s: %s", symbol, e)
        return None


def get_price_quote(user_input: str) -> str:
    key = user_input.upper().strip()
    yahoo_sym, label = (PRESET_SYMBOLS[key][0], PRESET_SYMBOLS[key][1]) \
                       if key in PRESET_SYMBOLS else (key, key)

    data = _yahoo_fetch(yahoo_sym)
    if not data:
        return f"Could not find price for *{key}*.\nTry: `price AAPL`, `price BTC`, `price GOLD`"

    arrow     = "up" if data["change"] >= 0 else "down"
    sign      = "+" if data["change"] >= 0 else ""
    state     = data["market_state"]
    state_lbl = ("Market Open" if state == "REGULAR"
                 else "Market Closed" if state == "CLOSED"
                 else state)
    price     = data["price"]
    price_str = f"{price:,.2f}" if price >= 1 else f"{price:.6f}"

    return (
        f"*{label}* (`{yahoo_sym}`)\n\n"
        f"Price:  `${price_str}`\n"
        f"Change: `{sign}{data['change']:.2f}` ({sign}{data['change_pct']:.2f}%) [{arrow}]\n"
        f"Prev Close: `${data['prev_close']:.2f}`\n\n"
        f"{state_lbl}\n"
        f"_as of {datetime.now().strftime('%Y-%m-%d %H:%M')}_"
    )


def get_top_movers() -> str:
    lines = [f"*Top Movers* -- `{datetime.now().strftime('%Y-%m-%d %H:%M')}`\n"]

    lines.append("*Indices*")
    for sym in MOVERS_INDICES:
        d = _yahoo_fetch(sym)
        if d:
            arrow = "^" if d["change"] >= 0 else "v"
            sign  = "+" if d["change"] >= 0 else ""
            lines.append(f"  {arrow} `{sym:<6}` ${d['price']:>10,.2f}  {sign}{d['change_pct']:.2f}%")

    stock_data = []
    for sym in MOVERS_STOCKS:
        d = _yahoo_fetch(sym)
        if d:
            stock_data.append(d)
        time.sleep(0.05)

    if stock_data:
        sorted_stocks = sorted(stock_data, key=lambda x: x["change_pct"], reverse=True)
        lines.append("\n*Top 5 Gainers*")
        for d in sorted_stocks[:5]:
            lines.append(f"  ^ `{d['symbol']:<6}` ${d['price']:>8.2f}  +{d['change_pct']:.2f}%")
        lines.append("\n*Top 5 Losers*")
        for d in sorted_stocks[-5:][::-1]:
            lines.append(f"  v `{d['symbol']:<6}` ${d['price']:>8.2f}  {d['change_pct']:.2f}%")
        most_active = sorted(stock_data, key=lambda x: abs(x["change_pct"]), reverse=True)[:5]
        lines.append("\n*Most Active*")
        for d in most_active:
            arrow = "^" if d["change"] >= 0 else "v"
            sign  = "+" if d["change"] >= 0 else ""
            lines.append(f"  {arrow} `{d['symbol']:<6}` ${d['price']:>8.2f}  {sign}{d['change_pct']:.2f}%")

    lines.append("\n*Crypto Movers*")
    crypto_data = []
    for sym in MOVERS_CRYPTO:
        d = _yahoo_fetch(sym)
        if d:
            crypto_data.append(d)
        time.sleep(0.05)

    if crypto_data:
        for d in sorted(crypto_data, key=lambda x: x["change_pct"], reverse=True):
            arrow     = "^" if d["change"] >= 0 else "v"
            sign      = "+" if d["change"] >= 0 else ""
            price_str = f"{d['price']:,.2f}" if d['price'] >= 1 else f"{d['price']:.6f}"
            lines.append(f"  {arrow} `{d['symbol']:<10}` ${price_str:>12}  {sign}{d['change_pct']:.2f}%")

    lines.append("\n_Data from Yahoo Finance_")
    return "\n".join(lines)


# ── Score explanation ─────────────────────────────────────────────────────

def get_score_explanation() -> str:
    # Score table uses plain text inside the code block.
    # The surrounding bold headings are safe (no underscores in parameter names).
    return (
        "*How the Score (0-100) Works*\n\n"
        "Every opportunity that passes all filters is scored on 5 factors.\n"
        "The score ranks results so the best trade is always number 1.\n\n"
        "```\n"
        "Factor          Weight  What it measures\n"
        "--------------- ------  ----------------------------------\n"
        "Ann. Return       30%   Annualised return on capital\n"
        "                        Premium / capital x 365 / DTE\n"
        "\n"
        "IV Score          20%   Absolute IV (linear: 45-100% range)\n"
        "                        Higher IV = richer premium to sell\n"
        "\n"
        "Theta Yield       20%   Daily theta divided by premium\n"
        "                        More decay per dollar = higher score\n"
        "\n"
        "Delta Safety      20%   How far OTM the strike is\n"
        "                        Lower delta = further OTM = safer\n"
        "\n"
        "Liquidity         10%   Bid/ask spread tightness\n"
        "                        Tighter = better fill price\n"
        "```\n\n"
        "*Score quality guide:*\n"
        "```\n"
        "80-100   Excellent  strong across all 5 factors\n"
        "60-79    Good       solid trade, minor weaknesses\n"
        "40-59    Fair       passes filters but not ideal\n"
        "below 40 Marginal   use caution, check detail card\n"
        "```\n\n"
        "*Important:* Score is relative to the current scan only.\n"
        "A score of 75 today vs 75 yesterday are not comparable.\n"
        "Always check the detail card (type: result 1) before trading.\n\n"
        "_To adjust scoring weights: edit_ `core/config.py` _weights section._"
    )


# ── Claude AI helper ──────────────────────────────────────────────────────

def ask_claude(question: str) -> str:
    """
    Send a question to Claude Sonnet via the Anthropic API.
    Returns the reply as a plain string suitable for Telegram.
    Requires ANTHROPIC_API_KEY in .env
    """
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        return (
            "ANTHROPIC_API_KEY not found in .env\n\n"
            "To enable Claude AI chat:\n"
            "1. Get your key at console.anthropic.com\n"
            "2. Add to .env: ANTHROPIC_API_KEY=sk-ant-...\n"
            "3. Restart the bot"
        )

    payload = json.dumps({
        "model":      CLAUDE_MODEL,
        "max_tokens": 1024,
        "system":     CLAUDE_SYSTEM_PROMPT,
        "messages":   [{"role": "user", "content": question}],
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            ANTHROPIC_API,
            data=payload,
            headers={
                "Content-Type":      "application/json",
                "x-api-key":         api_key,
                "anthropic-version": "2023-06-01",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())

        # Extract text from response
        content = data.get("content", [])
        text_blocks = [b["text"] for b in content if b.get("type") == "text"]
        return "\n".join(text_blocks).strip() if text_blocks else "No response received."

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        log.error("Claude API HTTP error %s: %s", e.code, body)
        if e.code == 401:
            return "Invalid ANTHROPIC_API_KEY. Check your .env file."
        if e.code == 429:
            return "Claude API rate limit hit. Please wait a moment and try again."
        if e.code == 400 and "credit balance is too low" in body:
            return (
                "Anthropic account has no credits.\n\n"
                "Add credits at: console.anthropic.com\n"
                "Go to Plans & Billing -> Add credits\n"
                "Minimum top-up is $5 (~1,600 questions).\n"
                "No restart needed once credits are added."
            )
        return f"Claude API error {e.code}. Try again shortly."
    except Exception as e:
        log.error("Claude API error: %s", e)
        return f"Could not reach Claude API: {e}"


# ── OpenRouter (Llama) AI helper ──────────────────────────────────────────

def ask_openrouter(question: str) -> str:
    """
    Send a question to Llama via OpenRouter API.
    Returns the reply as a plain string suitable for Telegram.
    Requires OPENROUTER_API_KEY in .env.
    OpenRouter uses OpenAI-compatible format.
    """
    api_key = os.getenv("OPENROUTER_API_KEY", "")
    if not api_key:
        return (
            "OPENROUTER_API_KEY not found in .env\n\n"
            "To enable Llama AI chat:\n"
            "1. Get your key at openrouter.ai/settings/keys\n"
            "2. Add to .env: OPENROUTER_API_KEY=sk-or-...\n"
            "3. Restart the bot"
        )

    payload = json.dumps({
        "model":    OPENROUTER_MODEL,
        "messages": [
            {"role": "system", "content": CLAUDE_SYSTEM_PROMPT},
            {"role": "user",   "content": question},
        ],
        "max_tokens": 1024,
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            OPENROUTER_API,
            data=payload,
            headers={
                "Content-Type":  "application/json",
                "Authorization": f"Bearer {api_key}",
                "X-Title":       "OptionBot",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())

        # OpenAI-compatible response: choices[0].message.content
        choices = data.get("choices", [])
        if choices:
            content = choices[0].get("message", {}).get("content", "")
            if content:
                return content.strip()
        return "No response received from Llama."

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        log.error("OpenRouter HTTP error %s: %s", e.code, body)
        if e.code == 401:
            return "Invalid OPENROUTER_API_KEY. Check your .env file."
        if e.code == 429:
            return "OpenRouter rate limit hit. Please wait a moment and try again."
        if e.code == 402:
            return (
                "OpenRouter account has insufficient credits.\n\n"
                "Top up at: openrouter.ai/settings/credits"
            )
        return f"OpenRouter API error {e.code}. Try again shortly."
    except Exception as e:
        log.error("OpenRouter error: %s", e)
        return f"Could not reach OpenRouter API: {e}"


# ── Health check helpers ──────────────────────────────────────────────────

def _health_check_ibkr() -> tuple:
    """
    Try a TCP socket connection to known IBKR ports.
    Returns (connected: bool, port: int or None, latency_ms: float or None).
    Fast (~1-3 sec) — does not use ib_insync, no data subscription started.
    """
    import socket
    ports = [7497, 4002, 7496, 4001]
    for port in ports:
        try:
            t0 = time.time()
            s  = socket.create_connection(("127.0.0.1", port), timeout=3)
            ms = (time.time() - t0) * 1000
            s.close()
            return True, port, ms
        except Exception:
            pass
    return False, None, None


def _health_check_claude_api() -> tuple:
    """
    TCP-level reachability check to api.anthropic.com:443.
    Returns (reachable: bool, latency_ms: float or None).
    No API key used, no tokens spent.
    """
    import socket
    try:
        t0 = time.time()
        s  = socket.create_connection(("api.anthropic.com", 443), timeout=8)
        ms = (time.time() - t0) * 1000
        s.close()
        return True, ms
    except Exception as e:
        log.debug("Claude API TCP check failed: %s", e)
        return False, None


def _health_check_openrouter() -> tuple:
    """
    TCP-level reachability check to openrouter.ai:443.
    Returns (reachable: bool, latency_ms: float or None).
    No API key used, no tokens spent.
    """
    import socket
    try:
        t0 = time.time()
        s  = socket.create_connection(("openrouter.ai", 443), timeout=8)
        ms = (time.time() - t0) * 1000
        s.close()
        return True, ms
    except Exception as e:
        log.debug("OpenRouter TCP check failed: %s", e)
        return False, None


def _health_check_supabase() -> tuple:
    """
    Try a lightweight Supabase query (select count from trade_candidates).
    Returns (ok: bool, detail: str).
    """
    try:
        from data.supabase_client import SupabaseClient
        sb = SupabaseClient()
        if not sb.is_enabled():
            return False, "Not configured (missing SUPABASE_URL / SUPABASE_KEY)"
        # Lightweight query — just fetch 1 row to confirm connection
        result = sb._client.table(SupabaseClient.TABLE_CANDIDATES).select("id").limit(1).execute()
        return True, "Connected"
    except Exception as e:
        log.debug("Supabase health check error: %s", e)
        return False, str(e)[:60]


def _health_market_status() -> str:
    """Return a short market open/closed status string."""
    try:
        import pytz
        et  = pytz.timezone("America/New_York")
        now = datetime.now(et)
    except ImportError:
        from datetime import timezone, timedelta
        month  = datetime.utcnow().month
        offset = -4 if 3 <= month <= 10 else -5
        now    = datetime.now(timezone(timedelta(hours=offset)))

    weekday = now.weekday()
    t_mins  = now.hour * 60 + now.minute
    open_   = 9 * 60 + 30
    close_  = 16 * 60

    if weekday >= 5:
        days_to_mon = 7 - weekday
        return f"CLOSED (weekend — opens Mon)"
    if t_mins < open_:
        opens_in = open_ - t_mins
        return f"CLOSED (opens in {opens_in}min at 09:30 ET)"
    if t_mins >= close_:
        return "CLOSED (after hours)"
    return f"OPEN ({now.strftime('%H:%M')} ET)"


# ── Help text ─────────────────────────────────────────────────────────────

def get_help() -> str:
    # Everything inside one ``` code block so Telegram renders it in
    # monospace font with correct column alignment. No Markdown symbols
    # outside the fences = no parse errors from underscores in param names.
    return (
        "```\n"
        "Sell Option Scanner -- Commands\n"
        "All commands work with or without leading /\n"
        "\n"
        "SCAN\n"
        "  /scan                scan full watchlist (CC + CSP)\n"
        "  /scan CC             scan full watchlist, covered calls only\n"
        "  /scan CSP            scan full watchlist, cash-secured puts only\n"
        "  /scan TSLA           scan TSLA (CC + CSP)\n"
        "  /scan TSLA CC        scan TSLA covered calls only\n"
        "  /scan TSLA CSP       scan TSLA cash-secured puts only\n"
        "  Auto-scan: 09:35 / 12:45 / 15:00 ET each trading day\n"
        "\n"
        "CONTROL\n"
        "  /stopscan    pause auto-scan (manual scan still works)\n"
        "  /cancelscan  stop a scan currently running\n"
        "  /lastscan    last scan summary, top 10 (instant)\n"
        "\n"
        "RESULTS\n"
        "  /fullresult  page 1 of all results (10 per page)\n"
        "  /next        next page of results\n"
        "  /previous    previous page of results\n"
        "  /result 5    full detail card for opportunity #5\n"
        "  /score       how the 0-100 score is calculated\n"
        "\n"
        "TRADE WORKFLOW\n"
        "  star <n>      star result #n for review later\n"
        "  /starredlist   show all starred candidates\n"
        "  approve <n>   approve starred #n (decision made)\n"
        "  /approvedlist  show all approved candidates\n"
        "  placed <n>    confirm order placed for approved #n\n"
        "  placed <n> 14:35  placed at specific time\n"
        "  /placedlist    show all placed/open trades\n"
        "  unstar <n>    remove #n from starred list\n"
        "  reject <n>    reject #n from starred or approved\n"
        "\n"
        "  Workflow: scan -> star -> approve -> placed\n"
        "  Score >= autostar threshold = auto-starred\n"
        "\n"
        "CONFIG\n"
        "  /config      show all settings + active overrides\n"
        "  set reset    clear ALL overrides, restore defaults\n"
        "  Overrides are permanent until 'set reset' is sent.\n"
        "\n"
        "  set min_dte 14            min days to expiry\n"
        "  set max_dte 42            max days to expiry\n"
        "  set strike_pct 0.20       strike range +/- % of price\n"
        "  set min_premium 2.00      min credit $\n"
        "  set min_ann_return 0.05   min annualised return\n"
        "  set min_theta 0.08        min daily theta $\n"
        "  set min_iv_rank 0         IV rank filter (0 = off)\n"
        "  set min_iv 0.40           raw IV floor (0 = off)\n"
        "  set cc_delta_min 0.20     CC min delta\n"
        "  set cc_delta_max 0.35     CC max delta\n"
        "  set csp_delta_min -0.35   CSP min delta\n"
        "  set csp_delta_max -0.20   CSP max delta\n"
        "  set min_oi 0              open interest (keep 0)\n"
        "  set max_spread 1.0        max bid/ask spread\n"
        "  set strategy both         both / cc / csp\n"
        "  set autostar 75           auto-star threshold (0=off)\n"
        "\n"
        "IV FILTER COMBOS\n"
        "  Default      set min_iv_rank 0   set min_iv 0.40\n"
        "  TSLA/hi-vol  set min_iv_rank 0   set min_iv 0.50\n"
        "  With IVR     set min_iv_rank 30  set min_iv 0.40\n"
        "  Wide scan    set min_iv_rank 0   set min_iv 0\n"
        "\n"
        "ASK AI\n"
        "  /askclaude what is theta decay\n"
        "  /askclaude when should I roll a covered call\n"
        "  /askllama explain the wheel strategy\n"
        "  /askllama what does IV rank 80 mean\n"
        "  Both commands accept any options / finance question.\n"
        "  askclaude uses Anthropic Claude (claude-sonnet-4-6)\n"
        "  askllama  uses OpenRouter Llama (llama-3.3-70b)\n"
        "\n"
        "MARKET DATA\n"
        "  price TSLA   latest price (stocks, crypto, indices)\n"
        "  price BTC / price GOLD / price VIX / price SPY\n"
        "  /movers      top gainers, losers, crypto\n"
        "\n"
        "SYSTEM\n"
        "  /health      system health check (IBKR, Supabase, Claude)\n"
        "  /stopbot     stop the bot (password required)\n"
        "\n"
        "TIPS\n"
        "  After scan: /fullresult -> browse, /next//previous to page\n"
        "              /result 1   -> top pick full detail\n"
        "  0 results?  try: set min_iv_rank 0\n"
        "              then: set min_iv 0.40\n"
        "  Keep min_oi at 0 (IBKR delayed data returns OI=0)\n"
        "  Type /score to understand the 0-100 ranking system\n"
        "```"
    )

# ── Results formatting helpers ────────────────────────────────────────────

def _format_results_page(results: list, page: int, scan_time, scanned_tickers: list) -> str:
    total       = len(results)
    total_pages = (total + RESULTS_PAGE_SIZE - 1) // RESULTS_PAGE_SIZE
    page        = max(1, min(page, total_pages))
    start       = (page - 1) * RESULTS_PAGE_SIZE
    end         = min(start + RESULTS_PAGE_SIZE, total)
    time_str    = scan_time.strftime("%Y-%m-%d %H:%M") if scan_time else "unknown"
    tickers_str = ", ".join(scanned_tickers) if scanned_tickers else "default watchlist"

    lines = [
        f"*Scan Results* -- Page {page}/{total_pages}  _({total} total)_",
        f"_{tickers_str} -- {time_str}_\n",
        "```",
        f"{'#':<3} {'Ticker':<6} {'T':<3} {'Strike':>7} {'DTE':>4} {'IV%':>5} {'Prem':>6} {'Scr':>5}",
        "-" * 44,
    ]
    for rank in range(start + 1, end + 1):
        o       = results[rank - 1]
        t_label = "CC" if o.strategy == "COVERED_CALL" else "CP"
        iv_pct  = f"{o.contract.implied_vol * 100:.0f}%"
        lines.append(
            f"{rank:<3} {o.contract.ticker:<6} {t_label:<3} "
            f"${o.contract.strike:>6.1f} "
            f"{o.contract.dte:>4} "
            f"{iv_pct:>5} "
            f"${o.contract.mid:>5.2f} "
            f"{o.score:>5.1f}"
        )
    lines.append("```")

    nav_parts = []
    if page > 1:
        nav_parts.append(f"`results {page - 1}` < prev")
    if page < total_pages:
        nav_parts.append(f"next > `results {page + 1}`")
    if nav_parts:
        lines.append("  ".join(nav_parts))
    lines.append(f"\n_Full detail: `result <#>`  e.g._ `result {start + 1}`")
    return "\n".join(lines)


def _format_result_detail(results: list, rank: int, scan_time, scanned_tickers: list) -> str:
    total = len(results)
    if rank < 1 or rank > total:
        return (
            f"Rank {rank} is out of range.\n"
            f"Valid range: `result 1` to `result {total}`\n\n"
            f"Send `results` to see the full list."
        )

    o              = results[rank - 1]
    c              = o.contract
    g              = o.greeks
    strategy_label = "Covered Call" if o.strategy == "COVERED_CALL" else "Cash-Secured Put"
    otm_pct        = abs(c.strike - c.underlying_price) / c.underlying_price * 100
    otm_dir        = "above" if o.strategy == "COVERED_CALL" else "below"
    spread_pct     = getattr(c, "spread_pct", 0) * 100
    spread_flag    = " [wide]" if spread_pct > 8 else ""
    iv_rank_str    = f"{o.iv_rank:.0f}" if o.iv_rank > 0 else "N/A"
    ann_ret_str    = f"{o.annualised_return * 100:.1f}%"
    theta_y_str    = f"{o.theta_yield * 100:.2f}%/day" if getattr(o, "theta_yield", None) else "--"

    if o.strategy == "COVERED_CALL":
        capital_str = f"${c.underlying_price * 100:,.0f}  (100 shares at ${c.underlying_price:.2f})"
        action_str  = f"Sell {c.ticker} ${c.strike:.1f} CALL  |  {c.dte}d to expiry"
    else:
        capital_str = f"${c.strike * 100:,.0f}  (cash reserve)"
        action_str  = f"Sell {c.ticker} ${c.strike:.1f} PUT   |  {c.dte}d to expiry"
        cost_basis  = c.strike - c.mid

    lines = [
        f"*#{rank} / {total} -- {strategy_label}*\n",
        f"`{action_str}`",
        f"_Underlying: ${c.underlying_price:.2f}  |  {otm_pct:.1f}% OTM {otm_dir}_",
        f"_Score: {o.score:.1f} / 100_\n",
        "```",
        f"-- Contract ------------------",
        f"Strike      : ${c.strike:.2f}",
        f"DTE         : {c.dte} days",
        f"",
        f"-- Premium -------------------",
        f"Bid / Ask   : ${c.bid:.2f} / ${c.ask:.2f}",
        f"Mid (credit): ${c.mid:.2f}",
        f"Spread      : {spread_pct:.1f}%{spread_flag}",
        f"",
        f"-- Greeks --------------------",
        f"Delta       : {g.delta:+.3f}",
        f"Theta       : ${g.theta:.3f}/day",
        f"Vega        : {g.vega:.3f}",
        f"Gamma       : {g.gamma:.4f}",
        f"",
        f"-- IV & Return ---------------",
        f"Implied Vol : {c.implied_vol * 100:.1f}%",
        f"IV Rank     : {iv_rank_str}",
        f"Ann. Return : {ann_ret_str}",
        f"Theta Yield : {theta_y_str}",
        f"",
        f"-- Liquidity -----------------",
        f"Open Int    : {c.open_interest}",
        f"Volume      : {c.volume}",
        f"",
        f"-- Capital -------------------",
        f"Required    : {capital_str}",
        "```",
    ]

    if o.strategy == "COVERED_CALL":
        lines.append(
            f"\n_Sell if you own 100 shares of {c.ticker}._\n"
            f"_Target: close at 50% profit (${c.mid * 0.5:.2f}) or {max(c.dte - 21, 1)}d DTE._"
        )
    else:
        lines.append(
            f"\n_Sell only if willing to own {c.ticker} at ${c.strike:.2f}._\n"
            f"_If assigned: cost basis = ${cost_basis:.2f} (strike - premium)._\n"
            f"_Target: close at 50% profit (${c.mid * 0.5:.2f}) or {max(c.dte - 21, 1)}d DTE._"
        )

    nav_parts = []
    if rank > 1:
        nav_parts.append(f"`result {rank - 1}` < prev")
    if rank < total:
        nav_parts.append(f"next > `result {rank + 1}`")
    if nav_parts:
        lines.append("\n" + "  ".join(nav_parts))
    lines.append(f"\n_Back to list: `results`_")
    return "\n".join(lines)


# ── Workflow list formatter ───────────────────────────────────────────────

def _format_candidate_list(rows: list, title: str, hint: str) -> str:
    """Format starredlist / approvedlist / placedlist for Telegram."""
    if not rows:
        return f"*{title}*\n\n_Nothing here yet._\n\n_{hint}_"

    lines = [f"*{title}* -- {len(rows)} item(s)\n", "```"]
    lines.append(
        f"{'#':<3} {'Date':<7} {'Ticker':<6} {'T':<3} "
        f"{'Strike':>7} {'Expiry':<10} {'Prem':>6} {'Scr':>5}"
    )
    lines.append("-" * 54)

    for i, row in enumerate(rows, 1):
        try:
            dt       = datetime.fromisoformat(str(row["scan_time"]).replace("Z", ""))
            date_str = dt.strftime("%d-%b")
        except Exception:
            date_str = "?"

        ticker  = str(row.get("ticker", "?"))[:6]
        strat   = row.get("strategy", "")
        t_label = "CC" if "CALL" in strat.upper() else "CP"
        strike  = float(row.get("strike", 0))
        expiry  = str(row.get("expiry", "?"))
        premium = float(row.get("premium", 0))
        score   = float(row.get("score", 0))

        lines.append(
            f"{i:<3} {date_str:<7} {ticker:<6} {t_label:<3} "
            f"${strike:>6.1f} {expiry:<10} "
            f"${premium:>5.2f} {score:>5.1f}"
        )

    lines.append("```")
    lines.append(f"\n_{hint}_")
    return "\n".join(lines)


def _try_fetch_price(ticker: str):
    """Fetch current Yahoo Finance price. Returns float or None."""
    try:
        data = _yahoo_fetch(ticker)
        if data and data.get("price", 0) > 0:
            return float(data["price"])
    except Exception as e:
        log.debug("_try_fetch_price %s failed: %s", ticker, e)
    return None


# ── Ticker validation ─────────────────────────────────────────────────────

def _validate_tickers(raw_tickers: List[str]):
    valid, invalid = [], []
    for t in raw_tickers:
        t = t.upper().strip()
        if not t:
            continue
        data = _yahoo_fetch(t)
        if data and data["price"] > 0:
            valid.append(t)
        else:
            invalid.append(t)
    return valid, invalid


# ── Bot Listener ──────────────────────────────────────────────────────────

class TelegramBotListener:
    def __init__(
        self,
        token: Optional[str] = None,
        chat_id: Optional[str] = None,
        scan_state=None,
        notifier=None,
    ):
        self.token    = token    or os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.chat_id  = chat_id  or os.getenv("TELEGRAM_CHAT_ID", "")
        self.state    = scan_state
        self.notifier = notifier
        self._offset  = 0
        self._running = False

        # Live config overrides — persist until `set reset` is sent.
        # Never cleared automatically by scans or bot restarts.
        self._config_overrides: dict = {}

        # Results pagination state — tracks current page for next/previous
        self._results_current_page: int = 1

        # Bot uptime tracking
        self._start_time: datetime = datetime.now()

        # stopbot password flow state
        self._stopbot_pending: bool      = False
        self._stopbot_pending_time: float = 0.0

        if not self.token:
            raise ValueError("Missing TELEGRAM_BOT_TOKEN in .env")

    def get_config_overrides(self) -> dict:
        """Called by scheduler to apply any live overrides set via Telegram."""
        return dict(self._config_overrides)

    def start(self):
        self._running = True
        # Register slash commands with Telegram so they show in autocomplete menu
        self._register_commands()
        # Drain any messages queued before this startup — prevents stale
        # commands (e.g. /stopbot) from firing the moment the bot starts.
        self._drain_queue()
        t = threading.Thread(target=self._poll_loop, daemon=True)
        t.start()
        log.info("Telegram bot listener started (polling)")
        return t

    def stop(self):
        self._running = False

    def _drain_queue(self):
        """
        Advance the offset past all messages currently in the Telegram queue.
        Called once at startup so stale commands queued while the bot was
        offline are silently skipped — they are never processed.
        """
        try:
            url    = TELEGRAM_API.format(token=self.token, method="getUpdates")
            params = urllib.parse.urlencode({"offset": -1, "timeout": 0})
            req    = urllib.request.Request(f"{url}?{params}", headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())
            updates = data.get("result", [])
            if updates:
                self._offset = updates[-1]["update_id"] + 1
                log.info("Startup drain: skipped %d pending message(s).", len(updates))
        except Exception as e:
            log.warning("Startup drain failed (non-fatal): %s", e)

    def _poll_loop(self):
        while self._running:
            try:
                updates = self._get_updates()
                for update in updates:
                    self._handle_update(update)
            except Exception as e:
                log.error("Poll error: %s", e)
            time.sleep(2)

    def _get_updates(self) -> list:
        url    = TELEGRAM_API.format(token=self.token, method="getUpdates")
        params = urllib.parse.urlencode({"offset": self._offset, "timeout": 10})
        req    = urllib.request.Request(f"{url}?{params}", headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        updates = data.get("result", [])
        if updates:
            self._offset = updates[-1]["update_id"] + 1
        return updates

    def _register_commands(self):
        """
        Register slash commands with Telegram so they appear in the autocomplete
        menu when the user types / in the chat. Safe to call on every start.
        """
        commands = [
            ("scan",         "Run option scan (full or custom tickers)"),
            ("stopscan",     "Pause auto-scheduled scans"),
            ("cancelscan",   "Cancel a scan currently in progress"),
            ("lastscan",     "Show last scan summary (top 10)"),
            ("fullresult",   "Browse all ranked results (paged)"),
            ("next",         "Next page of results"),
            ("previous",     "Previous page of results"),
            ("score",        "Explain the 0-100 scoring system"),
            ("starredlist",  "Show all starred candidates"),
            ("approvedlist", "Show all approved candidates"),
            ("placedlist",   "Show all placed/open trades"),
            ("config",       "Show current scan config and overrides"),
            ("movers",       "Top market movers (stocks, crypto, indices)"),
            ("askclaude",    "Ask Claude AI a question (Anthropic)"),
            ("askllama",     "Ask Llama AI a question (OpenRouter)"),
            ("health",       "System health check (IBKR, Supabase, Claude, OpenRouter)"),
            ("stopbot",      "Gracefully stop the bot (password required)"),
            ("help",         "Show all commands and usage guide"),
        ]
        try:
            url     = TELEGRAM_API.format(token=self.token, method="setMyCommands")
            payload = json.dumps(
                {"commands": [{"command": cmd, "description": desc} for cmd, desc in commands]}
            ).encode("utf-8")
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read())
            if result.get("ok"):
                log.info("Telegram slash commands registered (%d commands).", len(commands))
            else:
                log.warning("setMyCommands returned not-ok: %s", result)
        except Exception as e:
            log.warning("Could not register Telegram slash commands: %s", e)

    def _handle_update(self, update: dict):
        msg     = update.get("message", {})
        text    = msg.get("text", "").strip()
        chat_id = str(msg.get("chat", {}).get("id", ""))

        if not text:
            return
        if self.chat_id and chat_id != self.chat_id:
            log.warning("Message from unknown chat %s ignored", chat_id)
            return

        # ── stopbot password confirmation — checked BEFORE slash gate ────────
        # When waiting for a password, accept the reply regardless of whether
        # it starts with / (the password is plain text, not a slash command).
        if self._stopbot_pending:
            # Auto-cancel if too much time has passed
            if time.time() - self._stopbot_pending_time > STOPBOT_TIMEOUT_SECS:
                self._stopbot_pending = False
                self._send(chat_id,
                    "Stopbot request timed out (60s). Send `/stopbot` to try again.")
                return
            # Check password
            self._stopbot_pending = False
            if text.strip() == STOPBOT_PASSWORD:
                self._send(chat_id,
                    "🛑 *Bot shutting down...*\n\n"
                    "Password accepted. Goodbye!\n"
                    "_Restart with: `bash START_BOT.sh` or `bash START_BOT_BACKGROUND.sh`_"
                )
                time.sleep(1)   # give Telegram time to deliver the message
                log.info("stopbot command received — sending SIGTERM to self.")
                os.kill(os.getpid(), signal.SIGTERM)
            else:
                self._send(chat_id,
                    "❌ *Incorrect password.*\n\nBot is still running.\n"
                    "Send `/stopbot` again to retry.")
            return

        # ── Slash gate: only process messages that start with / ──────────────
        # Plain text messages are silently ignored.
        # Use /command to trigger any function (e.g. /scan TSLA, /help).
        if not text.startswith("/"):
            log.debug("Ignored plain text (no /): %s", text[:40])
            return

        # Strip the leading / and any @botname suffix (e.g. /scan@MyBot → scan)
        text = text[1:]
        if "@" in text:
            text = text.split("@")[0]

        log.info("Received command: /%s", text)
        lower = text.lower()
        parts = text.split()

        # ── scan ─────────────────────────────────────────────────────────
        if lower == "scan" or (lower.startswith("scan ") and len(parts) >= 2
                               and parts[1].upper() != "CONFIG"):
            if self.state is None:
                reply = "Scanner not available."
            elif self.state.is_running():
                reply = (
                    "A scan is *already in progress*.\n\n"
                    "Send `cancelscan` to stop it."
                )
            else:
                raw_parts = [p.upper() for p in parts[1:]] if len(parts) > 1 else []

                # Extract optional strategy token (CC / CSP / BOTH) from any position
                STRATEGY_TOKENS = {"CC": "cc", "CSP": "csp", "BOTH": "both"}
                scan_strategy = None
                ticker_parts  = []
                for p in raw_parts:
                    if p in STRATEGY_TOKENS:
                        scan_strategy = STRATEGY_TOKENS[p]
                    else:
                        ticker_parts.append(p)

                strategy_label = f" [{scan_strategy.upper()}]" if scan_strategy else ""

                if ticker_parts:
                    self._send(chat_id, f"Validating {len(ticker_parts)} ticker(s)...")
                    valid, invalid = _validate_tickers(ticker_parts)
                    if invalid:
                        invalid_str = ", ".join(f"`{t}`" for t in invalid)
                        if not valid:
                            self._send(chat_id, f"Unknown tickers: {invalid_str}")
                            return
                        self._send(chat_id, f"Skipping unknown: {invalid_str}")
                    tickers_to_scan = valid
                    ticker_str      = ", ".join(f"`{t}`" for t in tickers_to_scan)
                    self.state.request_scan(tickers=tickers_to_scan, strategy=scan_strategy)
                    reply = f"*Custom scan requested!*{strategy_label}\nScanning: {ticker_str}"
                else:
                    self.state.request_scan(tickers=None, strategy=scan_strategy)
                    watchlist_str = ", ".join(f"`{t}`" for t in DEFAULT_WATCHLIST)
                    reply = f"*Full scan requested!*{strategy_label}\nScanning: {watchlist_str}"

        # ── cancelscan ───────────────────────────────────────────────────
        elif lower == "cancelscan":
            if self.state is None:
                reply = "Scanner not available."
            elif not self.state.is_running():
                reply = "No scan is currently running."
            elif self.state.is_cancel_requested():
                # Cancel was already set but scan hasn't responded — scan is stuck.
                # Force-reset state so a new scan can start without restarting the bot.
                self.state.force_reset()
                reply = (
                    "*Force reset applied.*\n"
                    "Stuck scan cleared — send `scan` to start a fresh scan."
                )
            else:
                self.state.request_cancel()
                reply = "*Cancel requested.*\nStopping at next batch (~5-10 sec)."

        # ── stopscan ─────────────────────────────────────────────────────
        elif lower == "stopscan":
            if self.state is None:
                reply = "Scanner not available."
            elif not self.state.is_enabled():
                reply = "Scheduler is *already paused.*"
            else:
                self.state.disable_scheduler()
                reply = (
                    "*Scheduled scanner paused.*\n"
                    "Manual `scan` commands still work.\n\n"
                    "_Restart the bot to re-enable auto-scan._"
                )

        # ── lastscan ─────────────────────────────────────────────────────
        elif lower == "lastscan":
            reply = self._build_lastscan_reply()

        # ── fullresult <page> ─────────────────────────────────────────────
        elif lower == "fullresult" or lower.startswith("fullresult "):
            page = 1
            if len(parts) >= 2:
                try:
                    page = int(parts[1])
                except ValueError:
                    self._send(chat_id, "Usage: `fullresult` or `fullresult 2`")
                    return
            self._results_current_page = page
            reply = self._build_results_page_reply(page)

        # ── next ──────────────────────────────────────────────────────────
        elif lower == "next":
            results, _, count, _ = self._get_cached_results()
            if not results or count == 0:
                reply = "*No scan results.*\n\nSend `scan` to run a scan."
            else:
                total_pages = (count + RESULTS_PAGE_SIZE - 1) // RESULTS_PAGE_SIZE
                next_page   = min(self._results_current_page + 1, total_pages)
                self._results_current_page = next_page
                reply = self._build_results_page_reply(next_page)

        # ── previous ──────────────────────────────────────────────────────
        elif lower == "previous":
            results, _, count, _ = self._get_cached_results()
            if not results or count == 0:
                reply = "*No scan results.*\n\nSend `scan` to run a scan."
            else:
                prev_page = max(self._results_current_page - 1, 1)
                self._results_current_page = prev_page
                reply = self._build_results_page_reply(prev_page)

        # ── results <page> (kept for backwards compat) ────────────────────
        elif lower == "results" or lower.startswith("results "):
            page = 1
            if len(parts) >= 2:
                try:
                    page = int(parts[1])
                except ValueError:
                    self._send(chat_id, "Usage: `fullresult` or `fullresult 2`")
                    return
            self._results_current_page = page
            reply = self._build_results_page_reply(page)

        # ── result <rank> ─────────────────────────────────────────────────
        elif lower.startswith("result ") and len(parts) == 2:
            try:
                rank = int(parts[1])
            except ValueError:
                self._send(chat_id, "Usage: `result 5`  (rank number from `results`)")
                return
            reply = self._build_result_detail_reply(rank)

        # ── star <n> ──────────────────────────────────────────────────────
        elif lower.startswith("star ") and len(parts) == 2:
            reply = self._handle_star(chat_id, parts)

        # ── unstar <n> ────────────────────────────────────────────────────
        elif lower.startswith("unstar ") and len(parts) == 2:
            reply = self._handle_unstar(chat_id, parts)

        # ── approve <n> ───────────────────────────────────────────────────
        elif lower.startswith("approve ") and len(parts) == 2:
            reply = self._handle_approve(chat_id, parts)

        # ── placed <n> [HH:MM] ────────────────────────────────────────────
        elif lower.startswith("placed ") and len(parts) in (2, 3):
            reply = self._handle_placed(chat_id, parts)

        # ── reject <n> ────────────────────────────────────────────────────
        elif lower.startswith("reject ") and len(parts) == 2:
            reply = self._handle_reject(chat_id, parts)

        # ── starredlist ───────────────────────────────────────────────────
        elif lower == "starredlist":
            reply = self._handle_list("starred")

        # ── approvedlist ──────────────────────────────────────────────────
        elif lower == "approvedlist":
            reply = self._handle_list("approved")

        # ── placedlist ────────────────────────────────────────────────────
        elif lower == "placedlist":
            reply = self._handle_list("placed")

        # ── score ─────────────────────────────────────────────────────────
        elif lower == "score":
            reply = get_score_explanation()

        # ── askclaude <question> ──────────────────────────────────────────
        elif lower.startswith("askclaude ") and len(text) > 10:
            question = text[10:].strip()
            if not question:
                self._send(chat_id, "Usage: /askclaude <your question>", use_markdown=False)
                return
            self._send(chat_id, "🤖 Claude thinking...", use_markdown=False)
            answer = ask_claude(question)
            self._send(chat_id, answer, use_markdown=False)
            return

        # ── askllama <question> ───────────────────────────────────────────
        elif lower.startswith("askllama ") and len(text) > 9:
            question = text[9:].strip()
            if not question:
                self._send(chat_id, "Usage: /askllama <your question>", use_markdown=False)
                return
            self._send(chat_id, "🦙 Llama thinking...", use_markdown=False)
            answer = ask_openrouter(question)
            self._send(chat_id, answer, use_markdown=False)
            return

        # ── config ───────────────────────────────────────────────────────
        elif lower == "config":
            # Sent with Markdown ON so the ``` fences render as a code block.
            # Safe because ALL content is inside the code block — no Markdown
            # symbols outside it means nothing for the parser to misinterpret.
            reply = self._build_config_reply()

        # ── set <param> <value> — single or multi-line ───────────────────
        # Handles both formats:
        #   set min_iv_rank 0 min_iv 0.40          (single line, multiple pairs)
        #   set min_iv_rank 0\nset min_iv 0.40      (multiple lines, each with set)
        elif lower.startswith("set ") or all(
            ln.strip().lower().startswith("set ") or ln.strip() == ""
            for ln in text.splitlines() if ln.strip()
        ):
            reply = self._handle_set(parts, raw_text=text)

        # ── price ─────────────────────────────────────────────────────────
        elif lower.startswith("price "):
            ticker = text[6:].strip()
            reply  = get_price_quote(ticker)

        # ── movers ───────────────────────────────────────────────────────
        elif lower == "movers":
            self._send(chat_id, "Fetching top movers...")
            reply = get_top_movers()

        # ── health ────────────────────────────────────────────────────────
        elif lower == "health":
            self._send(chat_id, "Running health checks...")
            reply = self._handle_health()

        # ── stopbot ───────────────────────────────────────────────────────
        elif lower == "stopbot":
            self._stopbot_pending      = True
            self._stopbot_pending_time = time.time()
            reply = (
                "🛑 *Stop Bot Requested*\n\n"
                "Enter the password to confirm shutdown:\n"
                "_Wrong password or no reply in 60s = bot stays running._"
            )

        # ── help ──────────────────────────────────────────────────────────
        elif lower == "help":
            # Markdown ON so ``` fences render as code block.
            # Safe because all content is inside the code block — zero
            # Markdown symbols outside it means nothing to misparse.
            reply = get_help()

        else:
            reply = (
                "Unknown command: `/" + text + "`\n\n"
                "Send `/help` for all commands.\n"
                "Or: `/askclaude <question>` for Claude AI\n"
                "Or: `/askllama <question>` for Llama AI"
            )

        self._send(chat_id, reply)

    # ── Results paging ────────────────────────────────────────────────────

    def _get_cached_results(self):
        if self.state is None:
            return None, None, 0, []
        results, scan_time, count, scanned_tickers = self.state.get_last_results()
        return results, scan_time, count, scanned_tickers

    def _build_results_page_reply(self, page: int) -> str:
        results, scan_time, count, scanned_tickers = self._get_cached_results()
        if results is None:
            return "*No scan results yet.*\n\nSend `scan` to run a scan now."
        if count == 0:
            return "*Last scan found 0 opportunities.*\n\n_Send `config` to review thresholds._"
        total_pages = (count + RESULTS_PAGE_SIZE - 1) // RESULTS_PAGE_SIZE
        if page < 1 or page > total_pages:
            return f"Page {page} does not exist. Valid: 1 to {total_pages}.\n\nSend `results` for page 1."
        return _format_results_page(results, page, scan_time, scanned_tickers)

    def _build_result_detail_reply(self, rank: int) -> str:
        results, scan_time, count, scanned_tickers = self._get_cached_results()
        if results is None:
            return "*No scan results yet.*\n\nSend `scan` to run a scan now."
        if count == 0:
            return "*Last scan found 0 opportunities.*"
        return _format_result_detail(results, rank, scan_time, scanned_tickers)

    def _build_lastscan_reply(self) -> str:
        results, scan_time, count, scanned_tickers = self._get_cached_results()
        if results is None:
            return "*No scan results yet.*\n\nSend `scan` to run a scan now."

        time_str    = scan_time.strftime("%Y-%m-%d %H:%M") if scan_time else "Unknown"
        tickers_str = ", ".join(scanned_tickers) if scanned_tickers else "default watchlist"

        if count == 0:
            return (
                f"*Last Scan* -- `{time_str}`\n"
                f"Tickers: `{tickers_str}`\n\n"
                "No opportunities found.\n"
                "_Send `config` to review thresholds._"
            )

        preview_count = min(LASTSCAN_PREVIEW, count)
        lines = [
            f"*Last Scan* -- `{time_str}`",
            f"_Tickers: {tickers_str}_",
            f"_Showing top {preview_count} of {count} total_\n",
            "```",
            f"{'#':<3} {'Ticker':<6} {'T':<3} {'Strike':>7} {'DTE':>4} {'IV%':>5} {'Prem':>6} {'Scr':>5}",
            "-" * 44,
        ]
        for i, o in enumerate(results[:preview_count], 1):
            t_label = "CC" if o.strategy == "COVERED_CALL" else "CP"
            iv_pct  = f"{o.contract.implied_vol * 100:.0f}%"
            lines.append(
                f"{i:<3} {o.contract.ticker:<6} {t_label:<3} "
                f"${o.contract.strike:>6.1f} "
                f"{o.contract.dte:>4} "
                f"{iv_pct:>5} "
                f"${o.contract.mid:>5.2f} "
                f"{o.score:>5.1f}"
            )
        lines.append("```")

        if count > LASTSCAN_PREVIEW:
            remaining   = count - LASTSCAN_PREVIEW
            total_pages = (count + RESULTS_PAGE_SIZE - 1) // RESULTS_PAGE_SIZE
            lines.append(
                f"\n_{remaining} more not shown._\n"
                f"`fullresult` -- all {count} results ({total_pages} pages)\n"
                f"`result 1` -- full detail on top pick"
            )
        else:
            lines.append("\n_Send `result 1` for full detail on the top pick._")

        return "\n".join(lines)

    # ── Health check ──────────────────────────────────────────────────────

    def _handle_health(self) -> str:
        """
        Run live checks on all system components and return a formatted
        status card for Telegram. Each check is independent — one failure
        does not block the others.
        """
        lines = ["*System Health Check*\n"]

        # ── 1. Telegram (trivially OK — we received the command) ──────────
        lines.append("✅ Telegram        Connected")

        # ── 2. IBKR (TCP socket to known TWS/Gateway ports) ───────────────
        ibkr_ok, ibkr_port, ibkr_ms = _health_check_ibkr()
        if ibkr_ok:
            lines.append(f"✅ IBKR            Port {ibkr_port} ({ibkr_ms:.0f}ms)")
        else:
            lines.append(
                "❌ IBKR            Not reachable\n"
                "   Check: TWS or IB Gateway running?"
            )

        # ── 3. Supabase ───────────────────────────────────────────────────
        sb_ok, sb_detail = _health_check_supabase()
        if sb_ok:
            lines.append(f"✅ Supabase        {sb_detail}")
        else:
            lines.append(f"❌ Supabase        {sb_detail}")

        # ── 4. Claude API (TCP to api.anthropic.com:443) ──────────────────
        claude_ok, claude_ms = _health_check_claude_api()
        claude_key_ok = bool(os.getenv("ANTHROPIC_API_KEY", ""))
        if claude_ok:
            key_note = "" if claude_key_ok else " (⚠️ no API key)"
            lines.append(f"✅ Claude API      Reachable ({claude_ms:.0f}ms){key_note}")
        else:
            lines.append("❌ Claude API      Not reachable (check internet)")

        # ── 5. OpenRouter / Llama ─────────────────────────────────────────
        or_ok, or_ms = _health_check_openrouter()
        or_key_ok    = bool(os.getenv("OPENROUTER_API_KEY", ""))
        if or_ok:
            key_note = "" if or_key_ok else " (⚠️ no API key)"
            lines.append(f"✅ OpenRouter      Reachable ({or_ms:.0f}ms){key_note}")
        else:
            lines.append("❌ OpenRouter      Not reachable (check internet)")

        # ── 6. Market status ──────────────────────────────────────────────
        market_str = _health_market_status()
        lines.append(f"\n📊 *Market:* {market_str}")

        # ── 7. Next auto-scan slots ───────────────────────────────────────
        # Import SCAN_SLOTS from scheduler context if available
        try:
            from scheduler import SCAN_SLOTS
            slots_str = "  ".join(
                f"{h:02d}:{m:02d} [{lbl}]" for h, m, lbl in SCAN_SLOTS
            )
        except ImportError:
            slots_str = "09:35 [Open]  12:45 [Midday]  15:00 [Pre-Close]"
        lines.append(f"📅 *Auto-scan slots (ET):*\n`{slots_str}`")

        # ── 8. Scanner running status ─────────────────────────────────────
        if self.state is not None:
            if self.state.is_running():
                lines.append("⏳ *Scanner:* Scan in progress...")
            elif not self.state.is_enabled():
                lines.append("⏸ *Scanner:* Auto-scan paused (send `scan` for manual scan)")
            else:
                lines.append("💤 *Scanner:* Idle (waiting for next slot)")

        # ── 9. Bot uptime ─────────────────────────────────────────────────
        uptime_secs = int((datetime.now() - self._start_time).total_seconds())
        hours, rem  = divmod(uptime_secs, 3600)
        mins, secs  = divmod(rem, 60)
        if hours > 0:
            uptime_str = f"{hours}h {mins}m"
        elif mins > 0:
            uptime_str = f"{mins}m {secs}s"
        else:
            uptime_str = f"{secs}s"
        lines.append(f"⏱ *Bot uptime:* {uptime_str}")

        # ── 10. Active config overrides ───────────────────────────────────
        if self._config_overrides:
            ov_parts = [f"{k}={v}" for k, v in self._config_overrides.items()]
            lines.append(f"⚙️ *Overrides:* `{', '.join(ov_parts)}`")
        else:
            lines.append("⚙️ *Overrides:* none (all defaults)")

        lines.append(f"\n_Checked at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}_")
        return "\n".join(lines)

    # ── Workflow handlers — star / approve / placed / reject / lists ──────

    def _get_supabase(self):
        """Lazy-init Supabase client. Returns None if unavailable."""
        try:
            from dotenv import load_dotenv
            load_dotenv()
            from data.supabase_client import SupabaseClient
            client = SupabaseClient()
            if client.is_enabled():
                return client
        except Exception as e:
            log.error("Supabase init error: %s", e)
        return None

    def _handle_star(self, chat_id: str, parts: list) -> str:
        """star <n> — star result #n from the last scan (in-memory list)."""
        try:
            rank = int(parts[1])
        except ValueError:
            return "Usage: `star <n>`  e.g. `star 3`"

        results, scan_time, count, _ = self._get_cached_results()
        if not results or count == 0:
            return "*No scan results to star.*\n\nRun `scan` first."
        if rank < 1 or rank > count:
            return f"Rank {rank} out of range. Valid: 1 to {count}."

        o = results[rank - 1]
        sb = self._get_supabase()
        if not sb:
            return "Supabase not available — cannot star candidates."

        # Find existing pending row and update to starred.
        # Falls back to insert if no existing row found.
        result = sb.find_and_star(o, scan_time)
        if result == "error":
            return "Failed to star candidate. Try again."

        t_label = "CC" if o.strategy == "COVERED_CALL" else "CSP"
        note    = "" if result == "updated" else "\n_No existing record found — new entry created._"
        return (
            f"⭐ *Starred #{rank}*\n\n"
            f"`{o.contract.ticker} {t_label} ${o.contract.strike:.1f}` "
            f"exp {o.contract.expiry}  score {o.score:.1f}\n\n"
            f"_Send `starredlist` to review all starred candidates._"
            f"{note}"
        )

    def _handle_unstar(self, chat_id: str, parts: list) -> str:
        """unstar <n> — remove item #n from starredlist."""
        try:
            rank = int(parts[1])
        except ValueError:
            return "Usage: `unstar <n>`  e.g. `unstar 2`"

        sb = self._get_supabase()
        if not sb:
            return "Supabase not available."

        rows = sb.get_starred()
        if not rows:
            return "*Starred list is empty.*"
        if rank < 1 or rank > len(rows):
            return f"#{rank} not found. Send `starredlist` to see current items."

        candidate_id = rows[rank - 1]["id"]
        if sb.unstar_candidate(candidate_id):
            row = rows[rank - 1]
            return (
                f"↩ *Unstarred #{rank}*\n"
                f"`{row.get('ticker')} ${row.get('strike')} {row.get('expiry')}`\n\n"
                f"_Moved back to pending._"
            )
        return "Failed to unstar. Try again."

    def _handle_approve(self, chat_id: str, parts: list) -> str:
        """approve <n> — approve item #n from starredlist."""
        try:
            rank = int(parts[1])
        except ValueError:
            return "Usage: `approve <n>`  e.g. `approve 2`"

        sb = self._get_supabase()
        if not sb:
            return "Supabase not available."

        rows = sb.get_starred()
        if not rows:
            return "*Starred list is empty.*\n\nSend `starredlist` to check."
        if rank < 1 or rank > len(rows):
            return f"#{rank} not found in starred list. Send `starredlist` to see current items."

        candidate_id = rows[rank - 1]["id"]
        row          = rows[rank - 1]

        if sb.approve_candidate(candidate_id):
            t_label = "CC" if "CALL" in str(row.get("strategy", "")).upper() else "CSP"
            return (
                f"✅ *Approved #{rank}*\n\n"
                f"`{row.get('ticker')} {t_label} ${row.get('strike')} "
                f"exp {row.get('expiry')}`\n\n"
                f"_Decision made. Place order in IBKR when ready._\n"
                f"_Then send `placed <n>` from `approvedlist`._"
            )
        return "Failed to approve. Try again."

    def _handle_placed(self, chat_id: str, parts: list) -> str:
        """placed <n> [HH:MM] — confirm order placed for item #n from approvedlist."""
        try:
            rank = int(parts[1])
        except ValueError:
            return "Usage: `placed <n>`  or  `placed <n> 14:35`"

        # Optional time argument
        placed_at = None
        if len(parts) == 3:
            try:
                h, m     = parts[2].split(":")
                now      = datetime.now()
                placed_at = now.replace(hour=int(h), minute=int(m), second=0, microsecond=0)
            except Exception:
                return "Invalid time format. Use HH:MM e.g. `placed 1 14:35`"

        sb = self._get_supabase()
        if not sb:
            return "Supabase not available."

        rows = sb.get_approved()
        if not rows:
            return "*Approved list is empty.*\n\nSend `approvedlist` to check."
        if rank < 1 or rank > len(rows):
            return f"#{rank} not found in approved list. Send `approvedlist` to see current items."

        row          = rows[rank - 1]
        candidate_id = row["id"]
        ticker       = row.get("ticker", "")
        scan_premium = row.get("premium")   # option premium from scan (per share)

        # entry_price for options = the OPTION premium fill (per share, e.g. $1.25)
        # We cannot fetch live option prices from Yahoo — pass None so
        # place_candidate() uses the scan premium as the best estimate.
        # Ken updates the actual fill manually in TOS if it differs.
        ok = sb.place_candidate(candidate_id, entry_price=None, placed_at=placed_at)
        if ok:
            t_label      = "CC" if "CALL" in str(row.get("strategy", "")).upper() else "CSP"
            contracts    = int(row.get("contracts") or 1)
            scan_prem    = float(scan_premium) if scan_premium else None
            net_est      = round(scan_prem * 100 * contracts, 2) if scan_prem else None
            prem_str     = f"${scan_prem:.4f}/share  (~${net_est:.2f} total)" if scan_prem else "unknown — update manually"
            time_str     = (placed_at or datetime.now()).strftime("%H:%M")
            return (
                f"🚀 *Placed #{rank}*\n\n"
                f"`{ticker} {t_label} ${row.get('strike')} exp {row.get('expiry')}`\n\n"
                f"Scan premium : {prem_str}\n"
                f"Time logged  : {time_str}\n\n"
                f"_Entry price = scan estimate. Update actual fill in TOS if different._\n"
                f"_Send `placedlist` to see all open trades._"
            )
        return "Failed to log placed trade. Try again."

    def _handle_reject(self, chat_id: str, parts: list) -> str:
        """reject <n> — reject item #n from starredlist or approvedlist (starred first)."""
        try:
            rank = int(parts[1])
        except ValueError:
            return "Usage: `reject <n>`  e.g. `reject 2`"

        sb = self._get_supabase()
        if not sb:
            return "Supabase not available."

        # Try starred first, then approved
        rows   = sb.get_starred()
        source = "starred"
        if rank > len(rows):
            rows   = sb.get_approved()
            source = "approved"

        if not rows:
            return "*No starred or approved candidates to reject.*"
        if rank < 1 or rank > len(rows):
            return f"#{rank} not found. Send `starredlist` or `approvedlist` to check."

        row          = rows[rank - 1]
        candidate_id = row["id"]

        if sb.reject_candidate(candidate_id):
            t_label = "CC" if "CALL" in str(row.get("strategy", "")).upper() else "CSP"
            return (
                f"❌ *Rejected #{rank}* (from {source} list)\n\n"
                f"`{row.get('ticker')} {t_label} ${row.get('strike')} "
                f"exp {row.get('expiry')}`\n\n"
                f"_Removed from workflow._"
            )
        return "Failed to reject. Try again."

    def _handle_list(self, status: str) -> str:
        """Build starredlist / approvedlist / placedlist reply."""
        sb = self._get_supabase()
        if not sb:
            return "Supabase not available — cannot fetch list."

        if status == "starred":
            rows       = sb.get_starred()
            title      = "Starred Candidates"
            hint       = "approve <n> to approve  |  unstar <n> to remove  |  reject <n> to reject"
        elif status == "approved":
            rows       = sb.get_approved()
            title      = "Approved Candidates"
            hint       = "placed <n> to confirm order placed  |  reject <n> to reject"
        else:
            rows       = sb.get_placed()
            title      = "Placed Trades"
            hint       = "Trades logged to TOS. Update entry price manually if needed."

        return _format_candidate_list(rows, title, hint)

    # ── Config helpers ────────────────────────────────────────────────────

    def _build_config_reply(self) -> str:
        from core.config import ScannerConfig
        defaults = ScannerConfig()

        # Bot-level params that live in overrides only (not in ScannerConfig).
        BOT_PARAMS = {
            "autostar_threshold": 75.0,
        }

        lines = ["```"]
        lines.append("Current Scan Config")
        lines.append("")
        lines.append("%-18s %10s %10s" % ("Parameter", "Default", "Override"))
        lines.append("-" * 42)

        for param, (attr, typ, desc) in SETTABLE_PARAMS.items():
            if attr in BOT_PARAMS:
                default_val = BOT_PARAMS[attr]
            else:
                default_val = getattr(defaults, attr)
            override_val = self._config_overrides.get(attr, "-")
            lines.append("%-18s %10s %10s" % (param, str(default_val), str(override_val)))

        lines.append("")
        lines.append("-" * 42)
        lines.append("To change: set <param> <value>")
        lines.append("Multiple:  set min_iv_rank 0 min_iv 0.40")
        lines.append("e.g. set min_premium 2.00")
        lines.append("e.g. set autostar 75  (auto-star threshold)")
        lines.append("")
        lines.append("set reset  clear all overrides")
        lines.append("")
        lines.append("Notes:")
        lines.append("  min_iv_rank  needs IBKR history, set 0 if unavailable")
        lines.append("  min_iv       raw IV floor, always works, 0.40 = 40%")
        lines.append("  min_oi       keep 0, IBKR delayed data returns OI=0")
        lines.append("  autostar     score threshold for auto-starring (0=off)")
        lines.append("  Overrides are permanent until set reset is sent")
        lines.append("```")

        return "\n".join(lines)

    def _handle_set(self, parts: list, raw_text: str = "") -> str:
        # ── set reset ─────────────────────────────────────────────────────
        if len(parts) == 2 and parts[1].lower() == "reset":
            self._config_overrides.clear()
            return (
                "*All config overrides cleared.*\n"
                "All settings restored to defaults for next scan."
            )

        if len(parts) < 3:
            return (
                "Usage: `set <param> <value>`\n"
                "Multiple same line: `set min_iv_rank 0 min_iv 0.40`\n"
                "Multiple lines also works.\n"
                "Send `config` to see parameter names."
            )

        # ── Build token pairs — supports both formats: ────────────────────
        # Single line:  set param1 val1 param2 val2
        # Multi-line:   set param1 val1\nset param2 val2\nset param3 val3
        # Strategy: collect all (param, value) pairs from all lines.
        pairs = []   # list of (param_str, value_str)

        if raw_text:
            for line in raw_text.splitlines():
                line = line.strip()
                if not line:
                    continue
                line_parts = line.split()
                # Each line may start with "set" or just be "param value"
                tokens = line_parts[1:] if line_parts[0].lower() == "set" else line_parts
                if len(tokens) == 0:
                    continue
                if len(tokens) % 2 != 0:
                    # Odd tokens on this line — report and skip line
                    pairs.append((tokens[0], None))   # None value = error
                    continue
                for i in range(0, len(tokens), 2):
                    pairs.append((tokens[i], tokens[i + 1]))
        else:
            # Fallback: use parts as before
            tokens = parts[1:]
            if len(tokens) % 2 != 0:
                return (
                    "Each parameter needs a value.\n\n"
                    "Usage: `set <param> <value>`\n"
                    "Multiple: `set min_iv_rank 0 min_iv 0.40`\n"
                    "Send `config` to see all parameter names."
                )
            for i in range(0, len(tokens), 2):
                pairs.append((tokens[i], tokens[i + 1]))

        updated = []    # list of (param, value, desc)
        errors  = []    # list of error strings

        for param, raw_value in pairs:
            param = param.lower()
            if raw_value is None:
                errors.append(f"`{param}` -- missing value")
                continue

            if param not in SETTABLE_PARAMS:
                errors.append(f"`{param}` -- unknown parameter")
                continue

            attr, typ, desc = SETTABLE_PARAMS[param]

            try:
                if typ == int:
                    value = int(raw_value)
                elif typ == float:
                    value = float(raw_value)
                elif typ == str:
                    value = raw_value.lower()
                    if param == "strategy" and value not in ("cc", "csp", "both"):
                        errors.append("`strategy` must be `cc`, `csp`, or `both`")
                        continue
                else:
                    value = raw_value
            except ValueError:
                errors.append(
                    f"`{param}` -- invalid value `{raw_value}` (expected {typ.__name__})"
                )
                continue

            self._config_overrides[attr] = value
            log.info("Config override: %s = %s", attr, value)
            updated.append((param, value, desc))

        # ── Build reply ───────────────────────────────────────────────────
        lines = []

        if updated:
            # Everything inside ONE code block — avoids Telegram Markdown parse errors
            lines.append("```")
            lines.append("Config updated")
            lines.append("")
            lines.append("%-18s %12s" % ("Parameter", "New Value"))
            lines.append("-" * 32)
            for param, value, desc in updated:
                lines.append(f"{param:<18} {str(value):>12}")

            notes = []
            for param, value, _ in updated:
                if param == "min_iv_rank":
                    if value == 0:
                        notes.append("IV Rank disabled -- pair with min_iv as gate.")
                    elif value < 30:
                        notes.append(f"IV Rank {value} below 30 -- cheap premium, use carefully.")
                    elif value >= 50:
                        notes.append(f"IV Rank {value} -- high-vol only, fewer signals.")
                elif param == "min_iv":
                    if value == 0:
                        notes.append("Raw IV filter disabled -- no quality gate active.")
                    elif value < 0.30:
                        notes.append(f"IV {value*100:.0f}% is low -- thin-premium trades may appear.")
                    elif value >= 0.50:
                        notes.append(f"IV {value*100:.0f}% -- high-vol contracts only. Good for TSLA.")
                    else:
                        notes.append(f"Raw IV floor: {value*100:.0f}%. Below this IV = rejected.")
                elif param == "min_oi" and value > 0:
                    notes.append("Warning: IBKR delayed data returns OI=0.")
                    notes.append("This may reject everything. Use: set min_oi 0")
                elif param == "autostar":
                    if value == 0:
                        notes.append("Auto-star disabled. Use star <n> manually.")
                    else:
                        notes.append(f"Score >= {value:.0f} will be auto-starred after scan.")

            if notes:
                lines.append("")
                for note in notes:
                    lines.append(f"  {note}")

            lines.append("")
            lines.append("Overrides permanent until: set reset")
            lines.append("Applies to next scan. Send: scan or config")
            lines.append("```")

        if errors:
            lines.append("```")
            lines.append("Errors:")
            for err in errors:
                lines.append(f"  {err.replace(chr(96), '')}")
            lines.append("```")

        return "\n".join(lines) if lines else "Nothing was updated."

    def _send(self, chat_id: str, text: str, use_markdown: bool = True) -> bool:
        """
        Send a Telegram message.
        If Markdown causes a 400 Bad Request, automatically retries as plain
        text so the message always gets delivered even if formatting breaks.
        """
        url = TELEGRAM_API.format(token=self.token, method="sendMessage")

        def _do_send(parse_mode):
            body = {"chat_id": chat_id, "text": text,
                    "disable_web_page_preview": True}
            if parse_mode:
                body["parse_mode"] = parse_mode
            payload = json.dumps(body).encode("utf-8")
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())

        try:
            result = _do_send("Markdown" if use_markdown else None)
            if result.get("ok"):
                return True
            # Telegram returned ok=false without raising — treat as failure
            log.warning("Telegram send not ok: %s", result)
            return False

        except urllib.error.HTTPError as e:
            if e.code == 400 and use_markdown:
                # Markdown parse error — retry as plain text
                log.warning("Markdown parse error (400) — retrying as plain text")
                try:
                    result = _do_send(None)
                    return result.get("ok", False)
                except Exception as e2:
                    log.error("Send error (plain text retry): %s", e2)
                    return False
            log.error("Send error HTTP %s: %s", e.code, e)
            return False
        except Exception as e:
            log.error("Send error: %s", e)
            return False


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s -- %(message)s",
        datefmt="%H:%M:%S",
    )
    from dotenv import load_dotenv
    load_dotenv()
    bot = TelegramBotListener()
    log.info("Bot listener running. Send /help in Telegram.")
    bot.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        bot.stop()
