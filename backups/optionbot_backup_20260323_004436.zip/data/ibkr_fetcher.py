import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

"""
data/ibkr_fetcher.py
Uses Yahoo Finance for underlying prices (free, no subscription needed).
Uses IBKR only for option chain data (strikes, expirations, quotes).

Speed optimisation: batch reqMktData calls instead of one-by-one with sleep.
"""

import asyncio
import logging
import math
import random
import time
import urllib.request
import json
from datetime import date, datetime
from typing import List, Dict, Optional, Callable

from core.config import ScannerConfig
from core.models import OptionContract

log = logging.getLogger(__name__)

try:
    from ib_insync import IB, Stock, Option, util
    IB_AVAILABLE = True
except (ImportError, RuntimeError):
    IB_AVAILABLE = False
    log.warning("ib_insync not available.")

BATCH_SIZE = 30       # request this many contracts at once
BATCH_WAIT = 6.0      # seconds to wait for delayed/frozen data per batch


def _is_market_open() -> bool:
    """Returns True if US market is currently open (Mon-Fri 9:30-16:00 ET).
    Uses pytz if available for automatic DST handling, otherwise falls back
    to fixed UTC offset (EST=-5 Nov-Mar, EDT=-4 Mar-Nov).
    """
    from datetime import timezone, timedelta
    try:
        import pytz
        et = pytz.timezone("America/New_York")
        now = datetime.now(et)
    except ImportError:
        # Fallback: month-based DST approximation
        # EDT (UTC-4): March–October, EST (UTC-5): November–February
        month = datetime.utcnow().month
        # EDT (UTC-4): March 8 – November 1 approx
        # EST (UTC-5): November 1 – March 8 approx
        if 3 <= month <= 10:
            offset = -4  # EDT
        else:
            offset = -5  # EST
        et = timezone(timedelta(hours=offset))
        now = datetime.now(et)
    if now.weekday() >= 5:
        return False
    market_open  = now.replace(hour=9,  minute=30, second=0, microsecond=0)
    market_close = now.replace(hour=16, minute=0,  second=0, microsecond=0)
    return market_open <= now <= market_close


def _ensure_event_loop():
    """ib_insync needs an asyncio event loop — background threads don't have one."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError("closed")
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop


def get_price_yahoo(ticker: str) -> float:
    """Fetch current price from Yahoo Finance — free, no subscription needed."""
    try:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?interval=1d&range=1d"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        result = data["chart"]["result"][0]
        price = result["meta"].get("regularMarketPrice") or result["meta"].get("previousClose")
        if price and price > 0:
            log.info("%s price from Yahoo: $%.2f", ticker, price)
            return float(price)
    except Exception as e:
        log.warning("%s: Yahoo price failed: %s", ticker, e)
    return 0.0


class IBKRFetcher:
    def __init__(self, config: ScannerConfig):
        self.config = config
        self.ib: Optional["IB"] = None
        _ensure_event_loop()
        self._connect()

    def _connect(self):
        if not IB_AVAILABLE:
            raise RuntimeError("ib_insync not installed. Run: pip3 install ib_insync")

        ports = [7497, 4002, 7496, 4001]
        last_error = None
        for port in ports:
            client_id = random.randint(20, 99)
            try:
                log.info("Trying IBKR connection on port %d with clientId=%d...", port, client_id)
                self.ib = IB()
                self.ib.connect("127.0.0.1", port, clientId=client_id, timeout=10)
                log.info("Connected to IBKR on port %d (clientId=%d)", port, client_id)
                # Type 1 = live streaming (live account with data subscription)
                # Type 3 = delayed 15-min (fallback if no subscription)
                # Type 4 = delayed frozen (market closed / paper accounts)
                # Live account: use Type 1 when market open, Type 3 when closed
                if _is_market_open():
                    self.ib.reqMarketDataType(1)
                    log.info("Market OPEN — using live streaming data (Type 1)")
                else:
                    self.ib.reqMarketDataType(3)
                    log.info("Market CLOSED — using delayed data (Type 3)")
                return
            except Exception as e:
                last_error = e
                log.warning("Port %d failed: %s", port, e)
                try:
                    self.ib.disconnect()
                except Exception:
                    pass

        raise ConnectionError(
            f"Could not connect to TWS/IB Gateway on any port. "
            f"Make sure TWS is running and API is enabled. Last error: {last_error}"
        )

    def disconnect(self):
        if self.ib and self.ib.isConnected():
            try:
                self.ib.disconnect()
                log.info("Disconnected from IBKR.")
            except Exception as e:
                log.debug("Disconnect error: %s", e)

    def fetch_option_chain(
        self,
        ticker: str,
        progress_cb: Optional[Callable[[str], None]] = None,
    ) -> List[OptionContract]:
        """
        Fetch all option contracts for a ticker.
        progress_cb(msg) is called periodically so the caller can relay
        progress to Telegram.
        """
        cfg = self.config

        # 1. Yahoo price
        underlying_price = get_price_yahoo(ticker)
        if underlying_price <= 0:
            log.warning("%s: Could not get price from Yahoo", ticker)
            return []

        # 2. Qualify stock
        stock = Stock(ticker, "SMART", "USD")
        try:
            qualified = self.ib.qualifyContracts(stock)
        except Exception as e:
            log.warning("%s: qualifyContracts failed: %s", ticker, e)
            return []
        if not qualified:
            log.warning("%s: Could not qualify stock contract", ticker)
            return []

        # 3. Option chain definition
        try:
            chains = self.ib.reqSecDefOptParams(ticker, "", stock.secType, stock.conId)
        except Exception as e:
            log.warning("%s: reqSecDefOptParams failed: %s", ticker, e)
            return []
        if not chains:
            log.warning("%s: No option chain found", ticker)
            return []

        smart_chains = [c for c in chains if c.exchange == "SMART"]
        chain = smart_chains[0] if smart_chains else chains[0]

        # 4. Filter expirations by DTE
        today = date.today()
        valid_expirations = []
        for exp_str in sorted(chain.expirations):
            exp_date = datetime.strptime(exp_str, "%Y%m%d").date()
            dte = (exp_date - today).days
            if cfg.min_dte <= dte <= cfg.max_dte:
                valid_expirations.append((exp_str, exp_date, dte))

        if not valid_expirations:
            log.warning("%s: No expirations in DTE range %d-%d", ticker, cfg.min_dte, cfg.max_dte)
            return []

        # 5. Filter strikes within ±strike_range_pct of price
        valid_strikes = sorted([
            s for s in chain.strikes
            if underlying_price * (1 - cfg.strike_range_pct) <= s <= underlying_price * (1 + cfg.strike_range_pct)
        ])
        if not valid_strikes:
            log.warning("%s: No strikes near $%.2f", ticker, underlying_price)
            return []

        # 6. Option types
        option_types = []
        if cfg.strategy in ("cc", "both"):
            option_types.append("C")
        if cfg.strategy in ("csp", "both"):
            option_types.append("P")

        # 7. Build full list of contracts to fetch
        combos = [
            (exp_str, exp_date, dte, strike, opt_type)
            for (exp_str, exp_date, dte) in valid_expirations
            for strike in valid_strikes
            for opt_type in option_types
        ]

        total = len(combos)
        batches = [combos[i:i + BATCH_SIZE] for i in range(0, total, BATCH_SIZE)]
        log.info("%s: $%.2f | %d expirations | %d strikes | %d contracts to fetch",
                 ticker, underlying_price, len(valid_expirations), len(valid_strikes), total)

        if progress_cb:
            exp_lines = "  " + " · ".join(
                f"`{exp_date.strftime('%b %d')}` ({dte}d)"
                for (_, exp_date, dte) in valid_expirations
            )
            strike_min = valid_strikes[0]
            strike_max = valid_strikes[-1]
            est_mins_low  = max(1, len(batches) * int(BATCH_WAIT) // 60)
            est_mins_high = est_mins_low + 1
            market_status = (
                "🟢 Market OPEN — live delayed data"
                if _is_market_open() else
                "🔴 Market CLOSED — using frozen closing prices"
            )
            progress_cb(
                f"📡 *{ticker}* @ ${underlying_price:.2f}\n"
                f"{market_status}\n"
                f"\n"
                f"📅 *Expiries ({len(valid_expirations)}):*\n{exp_lines}\n"
                f"\n"
                f"🎯 *Strikes:* `${strike_min:.0f}` → `${strike_max:.0f}` "
                f"({len(valid_strikes)} strikes)\n"
                f"\n"
                f"⚙️ Fetching *{total} contracts* in batches of {BATCH_SIZE}...\n"
                f"_Est. time: ~{est_mins_low}–{est_mins_high} min_"
            )

        # 8. Batch fetch
        contracts: List[OptionContract] = []

        for batch_num, batch in enumerate(batches, 1):
            ticker_data_pairs = []

            for (exp_str, exp_date, dte, strike, opt_type) in batch:
                try:
                    opt = Option(ticker, exp_str, strike, opt_type, "SMART", multiplier="100")
                    opt.tradingClass = ticker
                    qualified_opt = self.ib.qualifyContracts(opt)
                    if not qualified_opt:
                        continue
                    td = self.ib.reqMktData(opt, "", False, False)
                    ticker_data_pairs.append((td, opt, exp_date, dte, strike, opt_type))
                except Exception as e:
                    log.debug("reqMktData failed %s %s %s: %s", exp_str, strike, opt_type, e)

            # Wait once for the whole batch
            self.ib.sleep(BATCH_WAIT)

            # On first batch: log raw field values to diagnose data availability
            if batch_num == 1 and ticker_data_pairs:
                td0, opt0, *_ = ticker_data_pairs[0]
                log.info("IBKR data sample — bid:%.3f ask:%.3f last:%.3f close:%.3f mid:%.3f iv:%.3f",
                         getattr(td0, "bid", -1) or -1,
                         getattr(td0, "ask", -1) or -1,
                         getattr(td0, "last", -1) or -1,
                         getattr(td0, "close", -1) or -1,
                         getattr(td0, "midpoint()", -1) or -1,
                         getattr(td0, "impliedVolatility", -1) or -1)

            # Read results
            for (td, opt, exp_date, dte, strike, opt_type) in ticker_data_pairs:
                try:
                    contract = self._parse_ticker_data(
                        td, opt, ticker, exp_date, dte, strike, opt_type, underlying_price
                    )
                    if contract:
                        contracts.append(contract)
                    self.ib.cancelMktData(opt)
                except Exception as e:
                    log.debug("Parse failed %s %s %s: %s", strike, opt_type, dte, e)

            # Progress update every 5 batches; cancel is checked every batch
            done = min(batch_num * BATCH_SIZE, total)
            if progress_cb:
                if batch_num % 5 == 0:
                    pct = int(done / total * 100)
                    progress_cb(
                        f"⏳ *{ticker}* scan progress: {pct}%\n"
                        f"({done}/{total} contracts fetched, {len(contracts)} valid so far)"
                    )
                else:
                    # Silent cancel check — no message sent, just raises if cancelled
                    progress_cb("")
            log.info("%s: batch %d/%d done — %d valid contracts so far",
                     ticker, batch_num, len(batches), len(contracts))

        log.info("%s: fetched %d valid option contracts", ticker, len(contracts))
        return contracts

    def _parse_ticker_data(self, td, opt, ticker, exp_date, dte,
                           strike, opt_type, underlying_price) -> Optional[OptionContract]:
        def safe_float(v, default=0.0):
            try:
                f = float(v)
                return f if not math.isnan(f) and f >= 0 else default
            except Exception:
                return default

        bid  = safe_float(td.bid)
        ask  = safe_float(td.ask)
        last = safe_float(td.last)
        volume = int(safe_float(td.volume))

        # IBKR frozen/delayed data field priority for after-hours:
        # close > last > midpoint — try each until we find a non-zero price
        close_price = safe_float(getattr(td, "close", 0))
        mid_price   = safe_float(getattr(td, "midpoint", 0))
        ref_price   = close_price or last or mid_price  # first non-zero wins

        iv = 0.30
        if hasattr(td, "impliedVolatility"):
            iv_val = safe_float(td.impliedVolatility, 0)
            if iv_val > 0:
                iv = iv_val
        # Also try modelGreeks for IV when direct field is empty
        if iv == 0.30 and hasattr(td, "modelGreeks") and td.modelGreeks:
            iv_val = safe_float(getattr(td.modelGreeks, "impliedVol", 0))
            if iv_val > 0:
                iv = iv_val

        # Accept contract if ANY price field has data.
        # Market open: use live bid/ask.
        # Market closed: bid/ask=0, fall back to close/last price.
        if bid <= 0 and ask <= 0:
            if ref_price > 0:
                bid = ref_price * 0.95
                ask = ref_price * 1.05
                log.debug("Price fallback %s %s %s: ref=%.3f (close=%.3f last=%.3f mid=%.3f)",
                          ticker, strike, opt_type, ref_price, close_price, last, mid_price)
            else:
                return None  # truly no price data at all

        # Use ref_price as last if last itself is 0
        if last <= 0 and ref_price > 0:
            last = ref_price

        return OptionContract(
            ticker=ticker,
            underlying_price=underlying_price,
            strike=strike,
            expiry=exp_date,
            dte=dte,
            option_type=opt_type,
            bid=bid,
            ask=ask,
            last=last,
            volume=volume,
            open_interest=0,
            implied_vol=iv,
        )

    def fetch_iv_history(self, ticker: str) -> Dict[str, float]:
        try:
            stock = Stock(ticker, "SMART", "USD")
            self.ib.qualifyContracts(stock)
            bars = self.ib.reqHistoricalData(
                stock,
                endDateTime="",
                durationStr="1 Y",
                barSizeSetting="1 day",
                whatToShow="OPTION_IMPLIED_VOLATILITY",
                useRTH=True,
            )
            if bars:
                ivs = [bar.close for bar in bars if bar.close > 0]
                if ivs:
                    return {"iv_52w_low": min(ivs), "iv_52w_high": max(ivs)}
        except Exception as e:
            log.debug("%s: IV history error: %s", ticker, e)
        return {"iv_52w_low": 0.15, "iv_52w_high": 0.60}
