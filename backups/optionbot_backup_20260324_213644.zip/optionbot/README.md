# 📊 Sell Option Scanner

A modular, Greeks-aware scanner for **Covered Calls** and **Cash-Secured Puts** on US stocks,
built on the Interactive Brokers API.

---

## Architecture

```
sell_option_scanner/
│
├── main.py                      # CLI entry point
│
├── core/
│   ├── config.py                # All tunable parameters (thresholds, weights)
│   ├── models.py                # Data classes: OptionContract, GreeksResult, ScanOpportunity
│   ├── greeks.py                # Black-Scholes Greeks engine (Delta, Theta, Vega, Gamma, Rho)
│   ├── scanner.py               # Main orchestrator (fetch → filter → score → rank)
│   └── scorer.py                # Composite scoring system (0–100)
│
├── strategies/
│   ├── covered_call.py          # Covered Call filter logic
│   └── cash_secured_put.py      # Cash-Secured Put filter logic
│
├── data/
│   ├── ibkr_fetcher.py          # Live IBKR data via ib_insync
│   └── mock_fetcher.py          # Synthetic data for testing (--dry-run)
│
├── output/
│   └── reporter.py              # Terminal table + CSV export
│
└── tests/
    └── test_greeks.py           # Unit tests for Greeks calculator
```

---

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Test Without IBKR (Dry Run)
```bash
python main.py --dry-run
```

### 3. Live Scan (Requires TWS/IB Gateway Running)
```bash
# Scan default watchlist
python main.py

# Scan specific tickers
python main.py --tickers SPY QQQ AAPL NVDA

# Only cash-secured puts
python main.py --strategy csp

# Only covered calls
python main.py --strategy cc

# Show top 20 + export CSV
python main.py --top 20 --export
```

---

## IBKR Setup

1. **Install TWS** (Trader Workstation) or **IB Gateway** from IBKR's website
2. Enable API: `Edit → Global Configuration → API → Settings`
   - ✅ Enable ActiveX and Socket Clients
   - ✅ Allow connections from localhost only
3. Default ports:
   - TWS Paper: `7497`
   - TWS Live: `7496`
   - IB Gateway Paper: `4002`
   - IB Gateway Live: `4001`
4. The scanner auto-detects the port.

---

## Greeks Reference (Seller's Perspective)

| Greek | What it measures | Ideal range for selling |
|-------|-----------------|------------------------|
| **Delta** | Directional exposure (prob of finishing ITM) | Calls: 0.20–0.35 / Puts: -0.35 to -0.20 |
| **Theta** | Daily time decay EARNED (your income) | Higher = better. Max ~30-45 DTE |
| **Vega** | P&L sensitivity to IV changes | Lower = safer. High vega = risk if IV spikes |
| **Gamma** | Rate of delta change | Avoid high gamma near expiry |
| **IV Rank** | How expensive options are vs history (0–100) | Sell when IVR > 30 (ideally > 50) |

---

## Scoring System

Each opportunity is scored 0–100 using a weighted composite:

| Factor | Weight | Logic |
|--------|--------|-------|
| IV Rank | 25% | Higher = richer premium |
| Theta Yield | 30% | Daily theta / premium received |
| Delta Safety | 20% | How far OTM |
| Liquidity | 15% | Open interest + tight spread |
| Ann. Return | 10% | Return on capital, annualised |

Adjust weights in `core/config.py`.

---

## Tuning the Scanner

Edit `core/config.py`:

```python
# Widen delta range to get more results
cc_delta_min = 0.15    # default 0.20
cc_delta_max = 0.45    # default 0.40

# Lower IV Rank threshold
min_iv_rank = 20       # default 30

# Accept lower premium
min_premium = 0.10     # default 0.20
```

---

## Roadmap → Automated Trading Bot

This scanner is designed as **Phase 1** of a full automated trading system:

```
Phase 1 (NOW): Sell Option Scanner ← you are here
      ↓
Phase 2: Add position tracking (open/close management)
      ↓
Phase 3: Auto-execution via IBKR placeOrder()
      ↓
Phase 4: Risk management (portfolio delta, max loss rules)
      ↓
Phase 5: Full Wheel Strategy automation (CSP → CC → repeat)
```

### Adding Auto-Execution (Phase 3 Preview)
```python
# In ibkr_fetcher.py, add:
from ib_insync import MarketOrder, LimitOrder

def place_sell_order(self, contract: OptionContract, limit_price: float):
    ib_contract = Option(
        contract.ticker, contract.expiry.strftime("%Y%m%d"),
        contract.strike, contract.option_type, "SMART"
    )
    order = LimitOrder("SELL", 1, limit_price)  # 1 contract = 100 shares
    trade = self.ib.placeOrder(ib_contract, order)
    return trade
```

---

## Running Tests
```bash
pip install pytest
pytest tests/ -v
```
