"""
core/scanner.py — Main Scanner Orchestrator
"""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))

import logging
from datetime import date, datetime
from typing import List, Optional, Callable

from core.config import ScannerConfig
from core.models import OptionContract, ScanOpportunity
from core.greeks import calculate_greeks, calculate_iv_rank, calculate_annualised_return
from data.ibkr_fetcher import IBKRFetcher
from data.mock_fetcher import MockFetcher
from strategies.covered_call import CoveredCallFilter
from strategies.cash_secured_put import CashSecuredPutFilter
from core.scorer import OpportunityScorer

log = logging.getLogger(__name__)


class OptionScanner:
    def __init__(self, config: ScannerConfig):
        self.config = config.validate()
        self.fetcher = MockFetcher(config) if config.dry_run else IBKRFetcher(config)
        self.scorer = OpportunityScorer(config)

        self.filters = []
        if config.strategy in ("cc", "both"):
            self.filters.append(CoveredCallFilter(config))
        if config.strategy in ("csp", "both"):
            self.filters.append(CashSecuredPutFilter(config))

    def run(
        self,
        progress_cb: Optional[Callable[[str], None]] = None,
    ) -> List[ScanOpportunity]:
        all_opportunities: List[ScanOpportunity] = []
        total_tickers = len(self.config.tickers)
        cfg = self.config

        # ── Send scan config summary to Telegram at start ────────────────
        if progress_cb:
            strategy_label = {
                "cc": "Covered Calls only",
                "csp": "Cash-Secured Puts only",
                "both": "CC + CSP",
            }.get(cfg.strategy, cfg.strategy)

            # IV filter status labels
            iv_rank_label = (
                f"{cfg.min_iv_rank:.0f}"
                if cfg.min_iv_rank > 0 else "OFF (no history)"
            )
            iv_abs_label = (
                f"{cfg.min_iv*100:.0f}%"
                if cfg.min_iv > 0 else "OFF"
            )
            # OI status label — remind user it's a data limitation
            oi_label = (
                f"{cfg.min_open_interest}"
                if cfg.min_open_interest > 0
                else "OFF (IBKR delayed data returns OI=0)"
            )

            progress_cb(
                f"\u2699\ufe0f *Scan Configuration*\n"
                f"```\n"
                f"Tickers   : {', '.join(cfg.tickers)}\n"
                f"Strategy  : {strategy_label}\n"
                f"DTE range : {cfg.min_dte}-{cfg.max_dte} days\n"
                f"Strike +/- : {cfg.strike_range_pct*100:.0f}% of price\n"
                f"----------------------\n"
                f"Min premium : ${cfg.min_premium:.2f}\n"
                f"Min theta   : ${cfg.min_theta:.3f}/day\n"
                f"Min ann ret : {cfg.min_annualised_return*100:.0f}%\n"
                f"----------------------\n"
                f"IV Rank     : {iv_rank_label}\n"
                f"IV (raw)    : {iv_abs_label}\n"
                f"----------------------\n"
                f"CC delta  : {cfg.cc_delta_min:.2f} to {cfg.cc_delta_max:.2f}\n"
                f"CSP delta : {cfg.csp_delta_min:.2f} to {cfg.csp_delta_max:.2f}\n"
                f"----------------------\n"
                f"Min OI    : {oi_label}\n"
                f"Min vol   : {cfg.min_volume}\n"
                f"Max spread: {cfg.max_bid_ask_spread_pct*100:.0f}% of mid\n"
                f"```"
            )

        for idx, ticker in enumerate(cfg.tickers, 1):
            log.info("Scanning %s...", ticker)
            if progress_cb:
                progress_cb(f"\U0001f50d Scanning *{ticker}* ({idx}/{total_tickers})...")
            try:
                opportunities, reject_summary = self._scan_ticker(ticker, progress_cb=progress_cb)
                all_opportunities.extend(opportunities)
                log.info("  %s -> %d opportunities found", ticker, len(opportunities))

                if progress_cb:
                    if opportunities:
                        progress_cb(f"OK *{ticker}* done - {len(opportunities)} opportunities found")
                    else:
                        progress_cb(
                            f"\u26a0\ufe0f *{ticker}* - 0 opportunities found\n\n"
                            f"{reject_summary}\n\n"
                            f"_Send_ `config` _to review thresholds, or_ `set` _to adjust live._"
                        )
            except Exception as e:
                log.error("  %s -> ERROR: %s", ticker, e)
                if progress_cb:
                    progress_cb(f"\u274c *{ticker}* error: `{e}`")

        for opp in all_opportunities:
            opp.score = self.scorer.score(opp)

        ranked = sorted(all_opportunities, key=lambda x: x.score, reverse=True)
        log.info("-" * 50)
        log.info("Total opportunities: %d across %d tickers", len(ranked), total_tickers)

        return ranked

    def _scan_ticker(
        self,
        ticker: str,
        progress_cb: Optional[Callable[[str], None]] = None,
    ):
        """Returns (opportunities, reject_summary_string)."""
        cfg = self.config

        chain = self.fetcher.fetch_option_chain(ticker, progress_cb=progress_cb)
        iv_history = self.fetcher.fetch_iv_history(ticker)

        # Rejection counters
        r_dte = r_liq = r_bid = r_spread = r_oi = r_vol = r_strategy = r_iv = 0
        passed_liq = 0
        opportunities = []

        if not chain:
            # Chain empty = all contracts had bid=0 (frozen data outside market hours)
            r_bid = -1  # signal: unknown count, fetcher filtered them

        for contract in chain:
            # DTE filter
            if not (cfg.min_dte <= contract.dte <= cfg.max_dte):
                r_dte += 1
                continue

            # Liquidity filters — tracked individually
            if contract.open_interest < cfg.min_open_interest:
                r_oi += 1
                continue
            if contract.volume < cfg.min_volume:
                r_vol += 1
                continue
            if contract.spread_pct > cfg.max_bid_ask_spread_pct:
                r_spread += 1
                continue
            if contract.bid <= 0:
                r_bid += 1
                continue

            passed_liq += 1

            # ── Absolute IV pre-filter ────────────────────────────────────
            # Applied before Greeks calculation as a fast early-exit.
            # Rejects contracts where the raw IV is below the configured floor.
            # This is independent of IV Rank — it reads directly from the quote.
            if cfg.min_iv > 0 and contract.implied_vol < cfg.min_iv:
                r_iv += 1
                log.debug(
                    "IV REJECT %s $%.2f: IV %.1f%% < min %.1f%%",
                    ticker, contract.strike,
                    contract.implied_vol * 100, cfg.min_iv * 100,
                )
                continue

            greeks = calculate_greeks(contract)
            iv_rank = calculate_iv_rank(
                contract.implied_vol,
                iv_history.get("iv_52w_low", contract.implied_vol * 0.7),
                iv_history.get("iv_52w_high", contract.implied_vol * 1.5),
            )
            ann_return = calculate_annualised_return(
                contract.mid, contract.underlying_price, contract.dte,
                "cc" if contract.is_call else "csp"
            )

            found = False
            for strategy_filter in self.filters:
                if strategy_filter.applies_to(contract):
                    opp = strategy_filter.evaluate(contract, greeks, iv_rank, ann_return)
                    if opp is not None:
                        opportunities.append(opp)
                        found = True
            if not found:
                r_strategy += 1

        total = len(chain)
        bid_zero_str = (
            f"ALL ({total}) - frozen data had no bid/ask"
            if r_bid == -1 else str(r_bid)
        )
        scanned_str = "0 (all filtered by fetcher)" if r_bid == -1 else str(total)

        # OI filter label: show as "disabled" if min_oi=0 so user understands
        oi_filter_label = (
            f"OI < {cfg.min_open_interest}"
            if cfg.min_open_interest > 0
            else "OI filter (disabled)"
        )
        iv_label = (
            f"IV < {cfg.min_iv*100:.0f}% (raw)"
            if cfg.min_iv > 0 else "IV (raw) filter (disabled)"
        )

        reject_summary = (
            f"Scanned          : {scanned_str}\n"
            f"Passed liquidity : {passed_liq}\n"
            f"---------------------\n"
            f"Bid=0 (no mkt data) : {bid_zero_str}\n"
            f"Spread too wide     : {r_spread}\n"
            f"{oi_filter_label:<20}: {r_oi}\n"
            f"Volume < {cfg.min_volume:<3}         : {r_vol}\n"
            f"DTE out of range    : {r_dte}\n"
            f"{iv_label:<20}: {r_iv}\n"
            f"Failed strategy     : {r_strategy}  (delta/IVRank/premium/theta)\n"
            f"---------------------\n"
            f"Opportunities       : {len(opportunities)}"
        )
        log.info("%s reject summary:\n%s", ticker, reject_summary)
        return opportunities, reject_summary

    # NOTE: Liquidity checks are inline in _scan_ticker() for
    # per-field rejection counters. No separate method needed.
