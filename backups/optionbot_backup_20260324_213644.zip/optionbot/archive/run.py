"""
run.py — Use this to run the scanner (Mac/Linux/Windows)
"""

import sys
import os

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

import importlib
main_module = importlib.import_module("main")
main_module.main()
