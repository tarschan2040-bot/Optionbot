' Run the bot in a minimized window — double click this to start silently
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c cd /d C:\Users\chkct\Desktop\python_project\optionbot && py -3.11 scheduler.py", 2, False
