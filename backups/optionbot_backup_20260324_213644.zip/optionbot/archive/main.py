"""
Sell Option Scanner — Main Entry Point
========================================
Scans US stocks for high-quality Covered Call and Cash-Secured Put
opportunities using IBKR data + Black-Scholes Greeks.

Usage:
    python main.py                  # scan default watchlist
    python main.py --tickers SPY QQQ AAPL TSLA
    python main.py --strategy csp   # only cash-secured puts
    python main.py --strategy cc    # only covered calls
    python main.py --dry-run        # skip IBKR, use mock data
"""
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))


import argparse
import logging
from datetime import datetime

from core.scanner import OptionScanner
from core.config import ScannerConfig
from output.reporter import Reporter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("main")


DEFAULT_WATCHLIST = [
    "SPY", "QQQ", "AAPL", "MSFT", "NVDA",
    "TSLA", "AMZN", "META", "GOOGL", "AMD",
]


def parse_args():
    p = argparse.ArgumentParser(description="Sell Option Scanner")
    p.add_argument("--tickers", nargs="+", default=DEFAULT_WATCHLIST)
    p.add_argument("--strategy", choices=["cc", "csp", "both"], default="both",
                   help="cc=Covered Call, csp=Cash-Secured Put, both=all")
    p.add_argument("--dry-run", action="store_true",
                   help="Use mock data instead of live IBKR connection")
    p.add_argument("--top", type=int, default=10,
                   help="Number of top opportunities to display")
    p.add_argument("--export", action="store_true",
                   help="Export results to CSV")
    return p.parse_args()


def main():
    args = parse_args()

    log.info("=" * 60)
    log.info("  SELL OPTION SCANNER  |  %s", datetime.now().strftime("%Y-%m-%d %H:%M"))
    log.info("=" * 60)
    log.info("Tickers  : %s", ", ".join(args.tickers))
    log.info("Strategy : %s", args.strategy.upper())
    log.info("Mode     : %s", "DRY RUN (mock data)" if args.dry_run else "LIVE (IBKR)")

    config = ScannerConfig(
        tickers=args.tickers,
        strategy=args.strategy,
        dry_run=args.dry_run,
    )

    scanner = OptionScanner(config)
    results = scanner.run()

    reporter = Reporter(results, top_n=args.top)
    reporter.print_table()

    if args.export:
        path = reporter.export_csv()
        log.info("Results exported → %s", path)

    return results


if __name__ == "__main__":
    main()
