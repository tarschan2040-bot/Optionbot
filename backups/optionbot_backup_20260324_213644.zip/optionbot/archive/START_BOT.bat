@echo off
title Sell Option Scanner Bot
cd /d C:\Users\chkct\Desktop\python_project\optionbot

echo.
echo ========================================
echo   Sell Option Scanner Bot Starting...
echo ========================================
echo.
echo Telegram bot will be ready in a few seconds.
echo Send 'help' in Telegram to get started.
echo.
echo To stop the bot, close this window.
echo ========================================
echo.

py -3.11 scheduler.py

echo.
echo Bot stopped. Press any key to restart, or close this window.
pause
py -3.11 START_BOT.bat
